import pygame
import os
from sys import exit
from constants import *
from bird import *
from assets import * 
from game_functions import *  
from main_menu import *
from pause_menu import *
from transition import *
from game_mode_menu import *
from tower_victory import *
from leaderboard import *
from backend import *
from auth import *
from classic_menu import *
from adventure_menu import *
from award import *
from login import *

notification_text = ""
notification_timer = 0
notification_y = -50

def show_notification(text):
    global notification_text, notification_timer, notification_y
    notification_text = text
    notification_timer = 120  # Show for 2 seconds at 60 FPS
    notification_y = -50 # Start position



# Robust import: prefer package import when available, fallback to local module
try:
    from CODES import database
except Exception:
    import database
import session
import backend

def add_score(username, score, mode):
    # Prefer the database module if available, then backend, otherwise local file
    try:
        if hasattr(database, "add_score"):
            return database.add_score(username, score, mode)
    except Exception:
        pass

    if hasattr(backend, "add_score"):
        try:
            return backend.add_score(username, score, mode)
        except Exception:
            pass

    try:
        with open("scores.txt", "a", encoding="utf-8") as f:
            f.write(f"{username},{score},{mode}\n")
        return True
    except Exception as e:
        print("Could not save score:", e)
        return False

# Change to the parent directory so relative paths work correctly
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


pygame.init ()
pygame.mixer.init ()

window = pygame.display.set_mode ((Game_Width, Game_Height))
pygame.display.set_caption ("Russel In The Wonderland")

clock = pygame.time.Clock ()
assets = load_assets ()


try:
    pygame.mixer.music.load ("SFX/background_music.ogg")
    pygame.mixer.music.set_volume (0.2)
    pygame.mixer.music.play (-1)
    music_playing = True
except:
    print ("Music file not found - game will run without music")
    music_playing = False


# === MAIN GAME LOOP FUNCTION ===
def run_game(game_mode="adventure"):
    global music_playing, notification_text, notification_timer, notification_y
    # == GAME VARIABLES ==
    bird_images = {
        "bird1": assets ["bird1"],
        "bird2": assets ["bird2"]
    }
    bird = Bird (bird_images)
    
    pipes = []
    velocity_x = -2
    velocity_y = 0
    gravity = 0.4
    jump_strength = -6
    Pipe_Osc_Freq = 0.002
    Pipe_Osc_Amp = 30
    score = 0
    high_score = 0
    game_over = False # Track game over state
    score_saved = False  # Track if score has been saved for Classic mode
    last_victory_score = 0 # Track last milestone for adventure mode
    victory_achieved = False  # To prevent multiple achievement awards
    victory_result = None # To capture result from victory screen
    achievement_10 = False
    achievement_20 = False
    achievement_30 = False
    achievement_40 = False
    achievement_50 = False
    victory_shown = False



    # == BACKGROUND VARIABLES ==
    bg_x1, bg_x2 = 0, Game_Width
    ground_x1, ground_x2 = 0, Game_Width
    ground_speed = 2

    create_pipe_timer = pygame.USEREVENT + 0
    pygame.time.set_timer (create_pipe_timer, 2000)

    def restart_game ():
        nonlocal bird, pipes, velocity_y, score, game_over, bg_x1, bg_x2, ground_x1, ground_x2, score_saved
        bird.y = bird_y
        pipes.clear ()
        velocity_y = 0
        score = 0
        bg_x1, bg_x2 = 0, Game_Width
        ground_x1, ground_x2 = 0, Game_Width
        game_over = False
        score_saved = False

    # === GAME LOOP ===
    while True:
        for event in pygame.event.get ():
            if event.type == pygame.QUIT:
                pygame.quit ()
                exit ()

            if event.type == create_pipe_timer and not game_over:
                create_pipe_pair (pipes, assets["top_pipe"], assets["bottom_pipe"])

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SPACE, pygame.K_w, pygame.K_UP):
                    if game_over:
                        restart_game ()
                    else:
                        velocity_y = jump_strength
                        assets["flap"].play ()
                        bird.start_flap ()

                elif event.key == pygame.K_q and game_over:
                    # Save score in Classic mode before returning to menu
                    if game_mode == "classic" and not score_saved:
                        
                        # Check if user is logged in
                        try:
                            current_user = session.get_user()
                        except Exception:
                            current_user = None

                        if current_user:
                            # If this is the player's first recorded best, award achievement
                            prev_best = database.get_best_score(current_user, "classic")
                            if prev_best is None:
                                if add_score(current_user, high_score, "classic"):
                                    database.add_achievement(current_user, "First Score")
                                    score_saved = True
                            else:
                                if add_score(current_user, high_score, "classic"):
                                    score_saved = True
                    fade_effect(window)
                    return "leaderboard"

                elif event.key in (pygame.K_p, pygame.K_ESCAPE):
                    game_snapshot = window.copy ()
                    action = pause_menu (window, clock, game_snapshot)
                    if action == "exit":
                        return # Exit to main menu
                    

                elif event.key == pygame.K_m:
                    music_playing = not music_playing
                    if music_playing:
                        pygame.mixer.music.unpause ()
                    else:
                        pygame.mixer.music.pause () 
                        
        if notification_timer > 0:
            notification_timer -= 1

        if not game_over:
            bird.update_animation ()
            bird.update_rotation (velocity_y)
            
            game_state = (
                velocity_y, score, high_score, game_over,
                velocity_x, gravity, jump_strength, Pipe_Osc_Freq,
                Pipe_Osc_Amp, ground_speed
            )

            velocity_y, score, high_score, game_over, velocity_x, gravity, jump_strength, Pipe_Osc_Freq, Pipe_Osc_Amp, ground_speed = move(bird, pipes, assets, game_state, game_mode)
            
            # Always i-check for bug sa adventure mode / new character unlocks every 30 points
            if game_mode == "adventure" and score >= 30:
                current_milestone = (score // 30) * 30
                
                if current_milestone > last_victory_score:
                    fade_effect (window)
                    victory_result = tower_victory_screen (window, clock, score)
            
                if victory_result == "continue":
                    last_victory_score = current_milestone

                elif victory_result == "menu":
                    return "menu"


            # Award simple achievements to logged-in users (duplicates are ignored by DB)
            try:
                current_user = session.get_user()
            except Exception:
                current_user = None

            if current_user:
                if game_mode == "adventure":
                    awards_earned = database.check_and_award_milestones(current_user, score, game_mode)
                    for award in awards_earned:
                        show_notification(f"Adventure Unlocked: {award}")

            if current_user:
                # example thresholds
                if score >= 10 and not achievement_10:
                    show_notification("Achievement Unlocked: Score 10+")
                    database.add_achievement(current_user, "Score 10+")
                    achievement_10 = True
                
                if score >= 20 and not achievement_20:
                    show_notification("Achievement Unlocked: Score 20+")
                    database.add_achievement(current_user, "Score 20+")
                    achievement_20= True

                if score >= 30 and not achievement_30:
                    show_notification("Achievement Unlocked: Score 30+")
                    database.add_achievement(current_user, "Score 30+")
                    achievement_30 = True

                if score >= 40 and not achievement_40:
                    show_notification("Achievement Unlocked: Score 40+")
                    database.add_achievement(current_user, "Score 40+")
                    achievement_40 = True

                if score >= 50 and not achievement_50:
                    show_notification("Achievement Unlocked: Score 50+")
                    database.add_achievement(current_user, "Score 50+")
                    achievement_50 = True
                    

                if game_mode == "adventure" and score >= 30 and not victory_achieved:
                    database.add_achievement(current_user, "Tower Victor")
                    victory_achieved = True

            # Background and ground scroll
            
            bg_multiplier = 0.6
            bg_x1 += velocity_x * bg_multiplier
            bg_x2 += velocity_x * bg_multiplier
            if bg_x1 <= -Game_Width:
                bg_x1 = bg_x2 + Game_Width
            if bg_x2 <= -Game_Width:
                bg_x2 = bg_x1 + Game_Width

            ground_x1 += ground_speed
            ground_x2 += ground_speed
            if ground_x1 <= -Game_Width:
                ground_x1 = ground_x2 + Game_Width
            if ground_x2 <= -Game_Width:
                ground_x2 = ground_x1 + Game_Width

        draw (window, bird, pipes, assets, score, high_score, game_over, bg_x1, bg_x2, ground_x1, ground_x2)

        if notification_timer > 0:
            notif_font = pygame.font.Font("FONT/flappy-font.ttf", 18)
            notif_text = notif_text = notif_font.render(notification_text, True, (255, 255, 255))
        

            if notification_y < 20:
                notification_y += 3

            notif_rect = notif_text.get_rect(center=(Game_Width // 2, notification_y))

            pygame.draw.rect(window, (255, 215, 0, 200), (notif_rect.x - 15, notif_rect.y - 8, notif_rect.width + 30, notif_rect.height + 16), border_radius=10)
            notif_text = notif_font.render(notification_text, True, (255, 255, 255))
            window.blit(notif_text, notif_rect)
            
        pygame.display.update()
        clock.tick(60)




# === MAIN PROGRAM FLOW ===
while True:
    # Show login screen first
    login_result = login_menu(window, assets, clock)
    
    if login_result == "main_menu":
        # User successfully logged in or signed up, proceed to main menu
        menu_active = True
        while menu_active:
            result = main_menu(window, assets, clock)

            if result == "logout":
                fade_effect(window)
                break
            
            elif result == "toggle_music":
                music_playing = not music_playing
                if music_playing:
                    pygame.mixer.music.unpause()
                else:
                    pygame.mixer.music.pause()
                continue

            elif result == "play":
                if music_playing and not pygame.mixer.music.get_busy():
                    pygame.mixer.music.play(-1)
                
                # Show game mode selection menu
                fade_effect(window)
                game_mode = game_mode_menu(window, assets, clock)
                fade_effect(window)
                
                if game_mode == "classic_menu":
                    fade_effect(window)
                    classic_result = classic_menu(window, assets, clock)
                    if classic_result == "classic":
                        game_result = run_game("classic")
                        if game_result == "menu":
                        # Return to menu after game ends
                            continue
                    elif classic_result == "back":
                        fade_effect(window)
                        continue

                # Selection to sa game menu ito yung sa adventure
                if game_mode == "adventure_menu":
                    fade_effect(window)
                    adventure_result = adventure_menu(window, assets, clock) 
                    if adventure_result == "adventure":
                        game_result = run_game("adventure")
                        if game_result == "menu":
                            continue

                    elif adventure_result == "back":
                        fade_effect(window)
                        continue

            elif result == "help":
                fade_effect(window)
                from help import help_menu
                help_result = help_menu(window, assets, clock)
                fade_effect(window)
                continue

            elif result == "awards":
                fade_effect(window)
                show_awards(window, clock)
                fade_effect(window)
                continue

            elif result == "leaderboard":
                fade_effect(window)
                show_leaderboard(window, clock)
                fade_effect(window)
                continue

            elif result == "quit":
                pygame.quit()
                exit()