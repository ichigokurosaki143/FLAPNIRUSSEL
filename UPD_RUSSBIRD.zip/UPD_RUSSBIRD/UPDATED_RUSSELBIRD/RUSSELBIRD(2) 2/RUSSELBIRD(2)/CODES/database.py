import sqlite3
import os
from datetime import datetime, timezone
from typing import List, Tuple, Optional

DB_NAME = os.environ.get("FLAPPY_DB", "flappybird.db")

def get_connection():
    # Use a longer timeout and WAL journaling to reduce 'database is locked' errors
    # Allow connections from other threads in case the game or web backend uses threads
    conn = sqlite3.connect(DB_NAME, timeout=30, check_same_thread=False)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 30000")
    except Exception:
        # If any PRAGMA fails, ignore but keep connection
        pass
    return conn

def force_fix_database():
    """Force fix all missing columns in database"""
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        print("Checking and fixing database schema...")
        
        # Check achievements table
        cur.execute("PRAGMA table_info(achievements)")
        achievement_columns = [col[1] for col in cur.fetchall()]
        
        # Add missing columns to achievements
        if 'game_mode' not in achievement_columns:
            print("Adding game_mode to achievements table...")
            cur.execute("ALTER TABLE achievements ADD COLUMN game_mode TEXT DEFAULT 'classic'")
        
        if 'earned_at' not in achievement_columns:
            print("Adding earned_at to achievements table...")
            cur.execute("ALTER TABLE achievements ADD COLUMN earned_at TEXT")
        
        # Check leaderboard table  
        cur.execute("PRAGMA table_info(leaderboard)")
        leaderboard_columns = [col[1] for col in cur.fetchall()]
        
        if 'game_mode' not in leaderboard_columns:
            print("Adding game_mode to leaderboard table...")
            cur.execute("ALTER TABLE leaderboard ADD COLUMN game_mode TEXT DEFAULT 'classic'")
        
        conn.commit()
        conn.close()
        print("Database schema fixed successfully!")
        
    except Exception as e:
        print(f"Database fix error: {e}")

def init_db():
    """Create necessary tables: users, leaderboard, achievements."""
    conn = get_connection()
    cur = conn.cursor()

    # Users table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )

    # Leaderboard table: supports multiple game modes (classic, adventure, etc.)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS leaderboard (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT NOT NULL,
            score INTEGER NOT NULL,
            played_at TEXT NOT NULL,
            game_mode TEXT DEFAULT 'classic',
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        );
        """
    )

    # Achievements table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            achievement_name TEXT NOT NULL,
            earned_at TEXT NOT NULL,
            game_mode TEXT DEFAULT 'classic',
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """
    )

    conn.commit()
    conn.close()


def _migrate_schema():
    """Apply lightweight migrations to add missing columns when the DB was created
    by an older schema. This keeps existing DB files working.
    """
    conn = get_connection()
    cur = conn.cursor()

    def table_columns(table_name):
        cur.execute(f"PRAGMA table_info({table_name})")
        return [r[1] for r in cur.fetchall()]

    try:
        # achievements: add game_mode if missing
        cols = table_columns('achievements')
        if 'game_mode' not in cols:
            print("Migrating: Adding game_mode to achievements table")
            cur.execute("ALTER TABLE achievements ADD COLUMN game_mode TEXT DEFAULT 'classic'")
        
        # Also ensure earned_at exists
        if 'earned_at' not in cols:
            print("Migrating: Adding earned_at to achievements table")
            cur.execute("ALTER TABLE achievements ADD COLUMN earned_at TEXT")
            
        # Update any existing records to have default game_mode
        cur.execute("UPDATE achievements SET game_mode = 'classic' WHERE game_mode IS NULL")
        
    except Exception as e:
        print(f"Migration warning: {e}")

    conn.commit()
    conn.close()


# Initialize DB on import
if not os.path.exists(DB_NAME):
    init_db()
else:
    try:
        init_db()
    except Exception:
        pass

# Run database fixes and migrations after all functions are defined
try:
    force_fix_database()
except Exception as e:
    print(f"Force fix error: {e}")

try:
    _migrate_schema()
except Exception as e:
    print(f"Migration error: {e}")


def add_user(username: str, password_hash: str) -> bool:
    """Create a new user. `password_hash` should be produced by werkzeug.security.generate_password_hash."""
    
    conn = None

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
            (username, password_hash, datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
        conn.close()
        return True
    
    except sqlite3.IntegrityError:
        print(f"User '{username}' Already exists.")
        return False
    except Exception as e:
        print(f"Error in add_user: {e}")
        return False
    
    finally:
        if conn:
            conn.close()

def authenticate_user(username: str) -> Optional[Tuple[int, str]]:
    """Return (user_id, password_hash) for a username, or None if not found."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        conn.close()
        return (row[0], row[1]) if row else None
    
    except Exception as e:
        print(f"Error in authenticate_user: {e}")
        return None


def add_score(username: str, score: int, game_mode: str = "classic") -> bool:
    """Insert a score; if a user exists with the username, link by user_id."""
    try:
        conn = get_connection()
        cur = conn.cursor()

        # Try find user id
        cur.execute("SELECT id FROM users WHERE username = ?", (username,))
        user = cur.fetchone()
        user_id = user[0] if user else None

        cur.execute(
            "INSERT INTO leaderboard (user_id, username, score, played_at, game_mode) VALUES (?, ?, ?, ?, ?)",
            (user_id, username, int(score), datetime.now(timezone.utc).isoformat(), game_mode),
        )
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error in add_score: {e}")
        return False


def get_best_score(username: str, mode: str = "classic") -> Optional[int]:
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT score FROM leaderboard WHERE username=? AND game_mode=? ORDER BY score DESC LIMIT 1",
            (username, mode),
        )
        result = cur.fetchone()
        conn.close()
        return int(result[0]) if result else None
    except Exception as e:
        print(f"Error in get_best_score: {e}")
        return None


def get_leaderboard(limit: int = 10, game_mode: str = "classic") -> List[Tuple[str, int, str, str]]:
    """Return list of rows: (username, score, played_at, game_mode)."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT username, score, played_at, game_mode FROM leaderboard WHERE game_mode = ? ORDER BY score DESC LIMIT ?",
            (game_mode, int(limit)),
        )
        rows = cur.fetchall()
        conn.close()
        return rows
    except Exception as e:
        print(f"Error in get_leaderboard: {e}")
        return []


def get_player_scores(username: str, game_mode: str = "classic", limit: int = 10) -> List[Tuple[int, str]]:
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT score, played_at FROM leaderboard WHERE username = ? AND game_mode = ? ORDER BY score DESC LIMIT ?",
            (username, game_mode, int(limit)),
        )
        rows = cur.fetchall()
        conn.close()
        return rows
    except Exception as e:
        print(f"Error in get_player_scores: {e}")
        return []


def add_achievement(username: str, achievement_name: str, game_mode: str = 'classic') -> bool:
    """Record an achievement for a user identified by username."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        cur.execute("SELECT id FROM users WHERE username = ?", (username,))
        user = cur.fetchone()
        if not user:
            conn.close()
            return False

        user_id = user[0]
        
        # Check if achievement already exists (with game_mode check)
        try:
            cur.execute(
                "SELECT COUNT(1) FROM achievements WHERE user_id = ? AND achievement_name = ? AND game_mode = ?",
                (user_id, achievement_name, game_mode),
            )
        except sqlite3.OperationalError:
            # If game_mode column doesn't exist yet, check without it
            cur.execute(
                "SELECT COUNT(1) FROM achievements WHERE user_id = ? AND achievement_name = ?",
                (user_id, achievement_name),
            )
            
        exists = cur.fetchone()
        if exists and exists[0] > 0:
            conn.close()
            return False

        # Insert achievement
        try:
            cur.execute(
                "INSERT INTO achievements (user_id, achievement_name, earned_at, game_mode) VALUES (?, ?, ?, ?)",
                (user_id, achievement_name, datetime.now(timezone.utc).isoformat(), game_mode),
            )
        except sqlite3.OperationalError:
            # If game_mode column doesn't exist yet, insert without it
            cur.execute(
                "INSERT INTO achievements (user_id, achievement_name, earned_at) VALUES (?, ?, ?)",
                (user_id, achievement_name, datetime.now(timezone.utc).isoformat()),
            )
            
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error in add_achievement: {e}")
        return False


def get_achievements(username: str, game_mode: str | None = None) -> List[Tuple[str, str, str]]:
    """Return list of (achievement_name, earned_at, game_mode) for a user.

    If `game_mode` is provided, filter achievements for that mode.
    """
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        # First, check if game_mode column exists
        cur.execute("PRAGMA table_info(achievements)")
        columns = [col[1] for col in cur.fetchall()]
        has_game_mode = 'game_mode' in columns
        
        cur.execute("SELECT id FROM users WHERE username = ?", (username,))
        user = cur.fetchone()
        if not user:
            conn.close()
            return []
        user_id = user[0]
        
        if has_game_mode:
            if game_mode:
                cur.execute(
                    "SELECT achievement_name, earned_at, game_mode FROM achievements WHERE user_id = ? AND game_mode = ? ORDER BY earned_at DESC",
                    (user_id, game_mode),
                )
            else:
                cur.execute(
                    "SELECT achievement_name, earned_at, game_mode FROM achievements WHERE user_id = ? ORDER BY earned_at DESC",
                    (user_id,),
                )
        else:
            # Fallback for old schema without game_mode
            if game_mode:
                cur.execute(
                    "SELECT achievement_name, earned_at, 'classic' as game_mode FROM achievements WHERE user_id = ? ORDER BY earned_at DESC",
                    (user_id,),
                )
            else:
                cur.execute(
                    "SELECT achievement_name, earned_at, 'classic' as game_mode FROM achievements WHERE user_id = ? ORDER BY earned_at DESC",
                    (user_id,),
                )
                
        rows = cur.fetchall()
        conn.close()
        return rows
    except Exception as e:
        print(f"Error in get_achievements: {e}")
        return []
    

def check_and_award_milestones (username: str, score: int, game_mode: str):
    # Check and award achievements for score milestones
    if game_mode != "adventure":
        return []
    
    milestones = [5, 10, 90, 120, 150]
    awards_given = []

    for milestone in milestones:
        if score >= milestone:
            award_name = f"Adventure {milestone} Points"
            if add_achievement (username, award_name, game_mode): # Successfully
                awards_given.append(award_name)

    return awards_given