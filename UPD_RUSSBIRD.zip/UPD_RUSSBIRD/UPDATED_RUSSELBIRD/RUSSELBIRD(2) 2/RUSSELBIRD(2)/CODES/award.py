# award.py
import pygame
from constants import Game_Width, Game_Height
import session

# Robust import: prefer package import when available, fallback to local module
try:
    from CODES import database
except Exception:
    import database

def show_awards(window, clock):
    """Display the awards panel - ADVENTURE AWARDS ONLY"""
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 36)
    font_award = pygame.font.Font("FONT/flappy-font.ttf", 24)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 18)
    
    # Get current user
    current_user = session.get_user()
    
    # Panel dimensions
    panel_x = 20
    panel_w = Game_Width - 40
    panel_y = 100
    panel_h = Game_Height - panel_y - 60
    panel_rect = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
    
    def render_awards():
        if not current_user:
            # Show login message
            no_user = font_award.render("Please login to view awards", True, (255,255,255))
            window.blit(no_user, (panel_x + (panel_w - no_user.get_width())//2, 
                                panel_y + panel_h//2 - 20))
            return
        
        # Get user's ADVENTURE achievements only
        adventure_awards = database.get_achievements(current_user, "adventure")

        filtered_awards = []
        for award in adventure_awards:
            award_name, date_earned, _ = award  # game_mode not needed
            if award_name.startswith("Adventure"):
                filtered_awards.append(award)

        if not filtered_awards:
            # No awards message - ADVENTURE SPECIFIC
            no_awards = font_award.render("No adventure awards yet. Reach 30+ points in Adventure mode!", True, (255,255,255))
            window.blit(no_awards, (panel_x + (panel_w - no_awards.get_width())//2, 
                                panel_y + panel_h//2 - 20))
            return
        
        # Display ADVENTURE awards only
        y_pos = panel_y + 20
        for award in filtered_awards:
            award_name, date_earned, _ = award  # game_mode not needed
            award_text = f"🏆 {award_name}"
            award_surface = font_award.render(award_text, True, (255, 215, 0))
            window.blit(award_surface, (panel_x + 20, y_pos))
            
            date_text = f"Earned: {date_earned[:10]}" if date_earned else "Earned: Recently"
            date_surface = font_small.render(date_text, True, (200, 200, 200))
            window.blit(date_surface, (panel_x + 20, y_pos + 30))
            
            y_pos += 60
            if y_pos > panel_y + panel_h - 40:
                break  # Don't overflow panel

    running = True
    while running:   
        # Handle events
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return 'quit'
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return 'menu'
        
        # Draw background
        window.fill((20, 30, 50))
        
        # Draw title
        title = font_title.render("ADVENTURE AWARDS", True, (255, 215, 0))
        window.blit(title, (Game_Width//2 - title.get_width()//2, 40))
        
        # Draw panel
        pygame.draw.rect(window, (18,28,48), panel_rect)
        pygame.draw.rect(window, (100,150,200), panel_rect, 3)
        
        # Render awards
        render_awards()
        
        # Instructions
        instr = font_small.render('Press ESC to return to menu', True, (150,200,255))
        window.blit(instr, (Game_Width//2 - instr.get_width()//2, Game_Height - 30))
        
        pygame.display.update()
        clock.tick(60)