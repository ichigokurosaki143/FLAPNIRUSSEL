# auth.py
import pygame
from constants import Game_Width, Game_Height
from werkzeug.security import generate_password_hash, check_password_hash

try:
    from CODES import database
except Exception:
    import database

import session

def auth_menu(window, assets, clock):
    """Login menu - Clean and Simple"""
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 40)
    font_text = pygame.font.Font("FONT/flappy-font.ttf", 24)
    font_medium = pygame.font.Font("FONT/flappy-font.ttf", 20)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 13)
    font_small2 = pygame.font.Font("FONT/flappy-font.ttf", 12)

    username = ""
    password = ""
    input_field = "username"
    message = ""
    message_timer = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "cancelled"
                if event.key == pygame.K_TAB:
                    input_field = "password" if input_field == "username" else "username"
                if event.key == pygame.K_RETURN:
                    if len(username) == 0 or len(password) == 0:
                        message = "Please enter username and password"
                        message_timer = 120
                    else:
                        # LOGIN attempt
                        auth = database.authenticate_user(username)
                        if auth:
                            user_id, pw_hash = auth
                            if check_password_hash(pw_hash, password):
                                session.set_user(username)
                                return "logged_in"
                            else:
                                message = "Incorrect password"
                                message_timer = 120
                        else:
                            message = "User not found"
                            message_timer = 120
                elif event.key == pygame.K_BACKSPACE:
                    if input_field == "username":
                        username = username[:-1]
                    else:
                        password = password[:-1]
                else:
                    ch = event.unicode
                    if ch and len(ch) == 1 and (ch.isalnum() or ch in " _-@"):
                        if input_field == "username" and len(username) < 20:
                            username += ch
                        if input_field == "password" and len(password) < 32:
                            password += ch

        if message_timer > 0:
            message_timer -= 1
        else:
            message = ""

        # DRAW EVERYTHING
        window.fill((20, 30, 50))
        
        # Title
        title = font_title.render("Login", True, (255, 215, 0))
        window.blit(title, (Game_Width//2 - title.get_width()//2, 80))

        # Input boxes
        input_w, input_h = 320, 40
        x = (Game_Width - input_w) // 2
        y = Game_Height//2 - 30

        pygame.draw.rect(window, (255,255,255), (x, y, input_w, input_h), border_radius=6)
        pygame.draw.rect(window, (200,200,200), (x, y+60, input_w, input_h), border_radius=6)

        # Text with cursor
        uname_disp = username + ("|" if input_field == "username" and (pygame.time.get_ticks()//500)%2 else "")
        pwd_disp = ("*" * len(password)) + ("|" if input_field == "password" and (pygame.time.get_ticks()//500)%2 else "")

        utext = font_text.render(uname_disp, True, (0,0,0))
        ptext = font_text.render(pwd_disp, True, (0,0,0))

        window.blit(utext, (x+10, y+8))
        window.blit(ptext, (x+10, y+68))

        # Field labels
        user_label = font_small.render("Username:", True, (255, 255, 255))
        pass_label = font_small.render("Password:", True, (255, 255, 255))
        window.blit(user_label, (x, y - 20))
        window.blit(pass_label, (x, y + 40))

        # LOGIN BUTTON (GREEN)
        login_rect = pygame.Rect(Game_Width//2 - 80, y + 120, 160, 40)
        mx, my = pygame.mouse.get_pos()
        
        if login_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 200, 100), login_rect, border_radius=6)
            pygame.draw.rect(window, (50, 150, 50), login_rect, 3, border_radius=6)
            if pygame.mouse.get_pressed()[0]:
                if len(username) == 0 or len(password) == 0:
                    message = "Please enter username and password"
                    message_timer = 120
                else:
                    auth = database.authenticate_user(username)
                    if auth:
                        user_id, pw_hash = auth
                        if check_password_hash(pw_hash, password):
                            session.set_user(username)
                            return "logged_in"
                        else:
                            message = "Incorrect password"
                            message_timer = 120
                    else:
                        message = "User not found"
                        message_timer = 120
        else:
            pygame.draw.rect(window, (80, 180, 80), login_rect, border_radius=6)
            pygame.draw.rect(window, (50, 150, 50), login_rect, 3, border_radius=6)
        
        login_text = font_medium.render("LOGIN", True, (255,255,255))
        window.blit(login_text, (login_rect.centerx - login_text.get_width()//2, login_rect.centery - login_text.get_height()//2))

        # STATIC TEXT ONLY (NOT CLICKABLE)
        info_font = pygame.font.Font("FONT/flappy-font.ttf", 14)
        info_text = info_font.render("Don't have an account? Sign up in login screen.", True, (255, 255, 255))
        window.blit(info_text, (Game_Width//2 - info_text.get_width()//2, y + 180))

        # Instructions
        instr = font_small2.render("TAB to switch field, ENTER to submit, ESC to cancel", True, (255, 255, 255))
        window.blit(instr, (Game_Width//2 - instr.get_width()//2, y + 220))

        # Error message
        if message:
            mtext = font_small.render(message, True, (255,100,100))
            window.blit(mtext, (Game_Width//2 - mtext.get_width()//2, y + 150))

        pygame.display.update()
        clock.tick(60)

def signup_menu(window, assets, clock):
    """Signup menu - Clean and Simple"""
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 40)
    font_text = pygame.font.Font("FONT/flappy-font.ttf", 24)
    font_medium = pygame.font.Font("FONT/flappy-font.ttf", 20)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 13)
    font_small2 = pygame.font.Font("FONT/flappy-font.ttf", 12)

    username = ""
    password = ""
    input_field = "username"
    message = ""
    message_timer = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "cancelled"
                if event.key == pygame.K_TAB:
                    input_field = "password" if input_field == "username" else "username"
                if event.key == pygame.K_RETURN:
                    if len(username) == 0 or len(password) == 0:
                        message = "Please enter username and password"
                        message_timer = 120
                    else:
                        # SIGN UP attempt
                        try:
                            ph = generate_password_hash(password)
                            ok = database.add_user(username, ph)
                            if ok:
                                session.set_user(username)
                                return "signed_up"
                            else:
                                message = "Username already exists!"
                                message_timer = 120
                        except Exception as e:
                            print(f"Signup error: {e}")
                            message = "Signup failed - try another username"
                            message_timer = 120
                elif event.key == pygame.K_BACKSPACE:
                    if input_field == "username":
                        username = username[:-1]
                    else:
                        password = password[:-1]
                else:
                    ch = event.unicode
                    if ch and len(ch) == 1 and (ch.isalnum() or ch in " _-@"):
                        if input_field == "username" and len(username) < 20:
                            username += ch
                        if input_field == "password" and len(password) < 32:
                            password += ch

        if message_timer > 0:
            message_timer -= 1
        else:
            message = ""

        # DRAW EVERYTHING
        window.fill((20, 30, 50))
        
        # Title
        title = font_title.render("Create Account", True, (255, 215, 0))
        window.blit(title, (Game_Width//2 - title.get_width()//2, 80))

        # Input boxes
        input_w, input_h = 320, 40
        x = (Game_Width - input_w) // 2
        y = Game_Height//2 - 30

        pygame.draw.rect(window, (255,255,255), (x, y, input_w, input_h), border_radius=6)
        pygame.draw.rect(window, (200,200,200), (x, y+60, input_w, input_h), border_radius=6)

        # Text with cursor
        uname_disp = username + ("|" if input_field == "username" and (pygame.time.get_ticks()//500)%2 else "")
        pwd_disp = ("*" * len(password)) + ("|" if input_field == "password" and (pygame.time.get_ticks()//500)%2 else "")

        utext = font_text.render(uname_disp, True, (0,0,0))
        ptext = font_text.render(pwd_disp, True, (0,0,0))

        window.blit(utext, (x+10, y+8))
        window.blit(ptext, (x+10, y+68))

        # Field labels
        user_label = font_small.render("Username:", True, (255, 255, 255))
        pass_label = font_small.render("Password:", True, (255, 255, 255))
        window.blit(user_label, (x, y - 20))
        window.blit(pass_label, (x, y + 40))

        # SIGN UP BUTTON (BLUE)
        signup_rect = pygame.Rect(Game_Width//2 - 80, y + 120, 160, 40)
        mx, my = pygame.mouse.get_pos()
        
        if signup_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (90, 150, 220), signup_rect, border_radius=6)
            pygame.draw.rect(window, (40, 100, 170), signup_rect, 3, border_radius=6)
            if pygame.mouse.get_pressed()[0]:
                if len(username) == 0 or len(password) == 0:
                    message = "Please enter username and password"
                    message_timer = 120
                else:
                    try:
                        ph = generate_password_hash(password)
                        ok = database.add_user(username, ph)
                        if ok:
                            session.set_user(username)
                            return "signed_up"
                        else:
                            message = "Username already exists!"
                            message_timer = 120
                    except Exception as e:
                        print(f"Signup error: {e}")
                        message = "Signup failed - try another username"
                        message_timer = 120
        else:
            pygame.draw.rect(window, (70, 130, 200), signup_rect, border_radius=6)
            pygame.draw.rect(window, (40, 100, 170), signup_rect, 3, border_radius=6)
        
        signup_text = font_medium.render("SIGN UP", True, (255,255,255))
        window.blit(signup_text, (signup_rect.centerx - signup_text.get_width()//2, signup_rect.centery - signup_text.get_height()//2))

        # STATIC TEXT ONLY (NOT CLICKABLE)
        info_font = pygame.font.Font("FONT/flappy-font.ttf", 14)
        info_text = info_font.render("Already have an account? Login in login screen.", True, (255, 255, 255))
        window.blit(info_text, (Game_Width//2 - info_text.get_width()//2, y + 180))

        # Instructions
        instr = font_small2.render("TAB to switch field, ENTER to submit, ESC to cancel", True, (255, 255, 255))
        window.blit(instr, (Game_Width//2 - instr.get_width()//2, y + 220))

        # Error message
        if message:
            mtext = font_small.render(message, True, (255,100,100))
            window.blit(mtext, (Game_Width//2 - mtext.get_width()//2, y + 150))

        pygame.display.update()
        clock.tick(60)