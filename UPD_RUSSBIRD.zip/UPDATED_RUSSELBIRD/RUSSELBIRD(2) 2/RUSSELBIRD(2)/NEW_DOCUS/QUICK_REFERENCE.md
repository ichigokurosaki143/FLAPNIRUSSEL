# QUICK REFERENCE - RUSSEL IN THE WONDERLAND CODE GUIDE

## 📋 Documentation Files Created

### 1. **HOW_THE_GAME_WORKS.md** (24.3 KB)
   - Comprehensive markdown documentation
   - Detailed module breakdowns
   - Physics explanations
   - Game flow diagrams
   - Architecture overview
   - **Best for**: Reading in browser or text editor

### 2. **GAME_EXPLANATION.py** (21.08 KB)
   - Executable Python documentation
   - Can be run with `python GAME_EXPLANATION.py`
   - Includes code structure analysis
   - Detailed explanations in comments
   - **Best for**: Quick reference in terminal

### 3. **QUICK_REFERENCE.md** (This file)
   - Fast lookup guide
   - Key concepts summary
   - Common questions answered

---

## 🎮 Game Architecture Overview

```
MAIN LOOP (60 FPS)
├── Event Handling
│   ├── Keyboard Input (Jump, Pause, Music, Quit)
│   └── Pipe Creation Timer (every 2 seconds)
├── Physics Update
│   ├── Apply Gravity
│   ├── Move Bird
│   ├── Move Pipes
│   └── Calculate Oscillation
├── Collision Detection
│   ├── Ground/Ceiling
│   ├── Pipes
│   └── Set Game Over Flag
├── Scoring System
│   ├── Detect Safe Passage
│   └── Update Difficulty Tier
├── Rendering
│   ├── Background (Parallax)
│   ├── Pipes
│   ├── Bird (with Rotation)
│   ├── Ground (Parallax)
│   └── Score UI
└── Frame Rate Cap (60 FPS)
```

---

## 📁 File Functions Quick Lookup

| File | Purpose | Key Class/Function |
|------|---------|-------------------|
| **main.py** | Game initialization & main loop | `run_game()` |
| **config.py** | Settings & difficulty | `GameConfig.get_difficulty_settings()` |
| **constants.py** | Static values | Game dimensions, bird/pipe sizes |
| **assets.py** | Resource loading | `load_assets()` |
| **bird.py** | Bird logic & animation | `Bird` class, `update_rotation()` |
| **pipes.py** | Pipe obstacles | `Pipe` class |
| **game_functions.py** | Physics & collision | `move()`, `draw()` |
| **main_menu.py** | Start screen | Menu UI loop |
| **pause_menu.py** | Pause screen | Pause UI |
| **help.py** | Help/instructions | Help screen UI |
| **transition.py** | Visual effects | `fade_effect()` |

---

## 🎯 Key Variables & Their Meanings

### Physics Variables (In main.py)
```python
velocity_y = 0          # Vertical speed (negative=up, positive=down)
velocity_x = -2         # Horizontal speed (negative=left/forward)
gravity = 0.4           # Downward acceleration per frame
jump_strength = -6      # Upward impulse when jumping
```

### Game State Variables
```python
score = 0               # Points earned this run
high_score = 0          # Best score in session
game_over = False       # Collision detected?
```

### Pipe Oscillation Variables
```python
Pipe_Osc_Freq = 0.002   # How fast pipes oscillate (sine wave)
Pipe_Osc_Amp = 30       # How far pipes move vertically (±pixels)
```

### Animation Variables (In Bird class)
```python
angle = 0               # Rotation (-25 to +25 degrees)
is_flapping = False     # Currently flapping wings?
flap_timer = 0          # Frames remaining in flap (0-8)
```

---

## 🎲 Difficulty Tiers Explained

| Score | Pipe Speed | Gravity | Jump | Oscillation |
|-------|-----------|---------|------|------------|
| 0-4 | -2.0 | 0.40 | -6.0 | ❌ Off |
| 5-9 | -2.8 | 0.42 | -6.3 | ❌ Off |
| **10-14** | **-3.3** | **0.45** | **-6.6** | **✅ ON** |
| 15-19 | -3.8 | 0.48 | -6.9 | ✅ Faster |
| 20+ | -4.3 | 0.50 | -7.2 | ✅ Fastest |

**Score 10 Milestone**: Game difficulty jumps when oscillation starts!

---

## ⌨️ Controls

| Key | Action | When Available |
|-----|--------|-----------------|
| SPACE / W / UP | Jump | Anytime in game |
| P / ESC | Toggle Pause | During gameplay |
| M | Toggle Music | Anywhere |
| Q | Quit to Menu | Game Over screen |
| B / ESC | Back | Help screen |
| Mouse Click | Select buttons | Menu screens |

---

## 🔄 Game State Transitions

```
START
  ↓
MAIN MENU ──→ HELP SCREEN ──→ MAIN MENU
  ↓                                ↑
GAME RUNNING                        │
  ├→ PAUSED ──→ RESUME ────────────┘
  │    ↓
  │   EXIT
  │    ↓
  └→ GAME OVER
     ├→ RESTART → GAME RUNNING
     └→ QUIT → MAIN MENU
```

---

## 📊 Physics Calculations Per Frame

### Gravity & Falling (Every Frame)
```
1. velocity_y += gravity
2. bird.y += velocity_y
3. If bird.y >= ground_level: game_over = True
```

### Pipe Movement (Every Frame)
```
1. pipe.x += velocity_x (negative = move left)
2. If score >= 10:
     offset = sin(elapsed_ms * frequency + phase) * amplitude
     pipe.y = base_y + offset
3. If pipe.x < -64: remove_from_list()
```

### Scoring (When Bird Passes Pipe)
```
If bird.x > pipe.x + pipe_width AND not pipe.passed:
    score += 1
    pipe.passed = True
    Check new difficulty tier
```

---

## 🎨 Rendering Order (Draw Last = On Top)

1. Background (parallax at 60% speed)
2. Pipes (obstacles)
3. Bird (player, with rotation)
4. Ground (parallax at 100% speed)
5. Score text (UI overlay)
6. Game Over screen (if active)

This order creates proper depth and visibility.

---

## 💾 Asset Management

### Images Loaded
```
Background:  IMAGES/flappybirdbg.png (scaled to 360x640)
Ground:      IMAGES/ground.png (scaled to 360x100)
Bird Idle:   IMAGES/bird1.png (34x24)
Bird Flap:   IMAGES/bird2.png (34x24)
Pipe Top:    IMAGES/top.png (64x512)
Pipe Bottom: IMAGES/bottom.png (64x512)
```

### Sounds Loaded
```
Wing Flap:   SFX/sfx_wing.wav (jump effect)
Point:       SFX/sfx_point.wav (scoring)
Hit:         SFX/sfx_hit.wav (collision)
Swoosh:      SFX/sfx_swooshing.wav (menu transition)
Die:         SFX/sfx_die.wav (game over)
Background:  SFX/background_music.ogg (loops)
```

---

## 🔍 Collision Detection System

### Three Collision Types

1. **Boundary Collision**
   ```
   ground_level = 640 - 62.5 - 24 = 553.5
   if bird.y >= 553.5 or bird.y <= 0:
       game_over = True
   ```

2. **Pipe Collision**
   ```
   if bird.colliderect(top_pipe) or bird.colliderect(bottom_pipe):
       game_over = True
   ```

3. **Safe Passage Scoring**
   ```
   if bird.x > pipe.x + 64 and not pipe.passed:
       score += 1  // Only happens once per pipe
   ```

---

## 🎬 Animation Details

### Bird Flapping Animation
```
Frame 0: Player presses jump
Frame 1-8: bird2 image shown (wings up)
Frame 9+: bird1 image shown (wings normal)
Duration: 8 frames at 60 FPS = 133ms flap
```

### Bird Rotation
```
Ascending (velocity < -5):   angle = +25° (nose up)
Neutral (-5 ≤ velocity ≤ 5): angle = 0°
Descending (velocity > 5):   angle = -25° (nose down)
```

### Menu Bird Bounce
```
offset = sin(time * 0.01) * 5
Result: Bird bobs up/down by ±5 pixels
```

---

## ⚡ Performance Specs

| Metric | Value |
|--------|-------|
| Target FPS | 60 |
| Frame Time | 16.67ms |
| Resolution | 360x640 |
| Pipe Creation | Every 2000ms |
| Score Check | Every frame |
| Difficulty Update | On score change |
| Memory Usage | ~50MB (estimated) |

---

## 🔧 Common Tweaks (In config.py)

```python
# Make game easier
BIRD_START_Y = 350  # Start higher
PIPE_OPENING_SPACE = 150  # Wider gaps

# Make game harder
BIRD_START_Y = 280  # Start lower
PIPE_OPENING_SPACE = 100  # Narrower gaps

# Faster scrolling
velocity_x = -3  # Was -2

# More oscillation
PIPE_OSCILLATION_AMPLITUDE = 50  # Was 30
```

---

## 📚 Learning Path

### To Understand The Code:
1. **Start**: Read `main.py` (game flow)
2. **Then**: Study `game_functions.py` (physics)
3. **Next**: Check `bird.py` (animation)
4. **Finally**: Explore `config.py` (difficulty)

### To Modify The Game:
1. Change settings in `config.py`
2. Test in `main.py`
3. Adjust physics in `game_functions.py`
4. Add features to appropriate modules

### To Add New Features:
1. **New Menu Screen**: Follow `main_menu.py` pattern
2. **New Sound**: Add to `assets.py` load_assets()
3. **New Sprite**: Add image to IMAGES/ and load in `assets.py`
4. **New Difficulty Tier**: Update `config.py`

---

## ✅ Code Quality Checklist

- ✓ Modular architecture (files separated by function)
- ✓ Configuration centralized (easy tweaking)
- ✓ Asset loading with path resolution (works from any directory)
- ✓ Professional UI (menus, pause, help)
- ✓ Sound feedback (actions have audio)
- ✓ Smooth animations (60 FPS target)
- ✓ Responsive controls (immediate feedback)
- ✓ Efficient collision (pygame.Rect built-in)
- ✓ Clean code structure (readable, maintainable)

---

## 🎓 Advanced Concepts Used

1. **Object-Oriented Programming**: Bird and Pipe classes
2. **Inheritance**: Both inherit from pygame.Rect
3. **Physics Simulation**: Gravity, velocity, acceleration
4. **Trigonometric Functions**: Sine wave for oscillation
5. **State Machines**: Game states (menu, playing, paused, over)
6. **Event-Driven Programming**: Pygame event system
7. **Parallax Scrolling**: Multiple layers at different speeds
8. **Frame-Based Animation**: Timed sprite updates
9. **Difficulty Scaling**: Dynamic parameter adjustment
10. **Resource Management**: Asset caching and cleanup

---

## 📞 Quick Help

**Q: Why does the game lag on startup?**
A: First asset load takes time. Subsequent runs are smooth.

**Q: Can I change difficulty without restarting?**
A: Yes! Edit SCREEN_HEIGHT or BIRD_START_Y in config.py

**Q: How do pipes oscillate?**
A: Sine wave function creates smooth up/down movement

**Q: Why does jumping work differently at higher scores?**
A: Jump power increases to compensate for stronger gravity

**Q: Can I save high scores?**
A: Currently session-only. Could add file saving in future

---

## 🚀 Next Steps for Enhancement

1. **Persistent High Scores**: Save to JSON file
2. **Leaderboard**: Track top 10 scores
3. **Power-ups**: Special items during gameplay
4. **Different Skins**: Multiple bird characters
5. **Sound Settings**: Volume control in menu
6. **Statistics**: Track plays, total points, best streak
7. **Achievements**: Unlock badges for milestones
8. **Settings Menu**: Customize difficulty, sounds, etc.

---

## 📖 File Reading Order

**For Complete Understanding**, read in this order:
1. `HOW_THE_GAME_WORKS.md` - Full overview
2. `GAME_EXPLANATION.py` - Detailed breakdown
3. `QUICK_REFERENCE.md` - Quick lookup (this file)
4. Source code files - Implementation details

**All three documents are in the CODES/ folder!**

---

Created: November 16, 2025 | Pygame-CE 2.5.6 | Python 3.14.0+
