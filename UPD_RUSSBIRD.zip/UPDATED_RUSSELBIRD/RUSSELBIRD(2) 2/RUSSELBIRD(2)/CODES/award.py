# award.py
import pygame
from constants import Game_Width, Game_Height
import session
from adventure_menu import *

# Robust import: prefer package import when available, fallback to local module
try:
    from CODES import database
except Exception:
    import database

def show_awards(window, clock, start_mode: str = 'awards'):
    """
    Display the award panel
    """
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 40)
    font_rank = pygame.font.Font("FONT/flappy-font.ttf", 24)
    font_score = pygame.font.Font("FONT/flappy-font.ttf", 22)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 12)
    
    # UI mode and sub-page
    ui_mode = start_mode
    sub_page = 'award'  # Define sub_page
    scroll = {"award": 0}

    # Panel dimensions
    panel_x = 20
    panel_w = Game_Width - 40
    panel_y = 120
    panel_h = Game_Height - panel_y - 60
    panel_rect = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
    
    # Define buttons (example - adjust as needed)
    btn_award = pygame.Rect(Game_Width//2 - 100, 60, 200, 40)

    def truncate_text(font, text, max_width):
        """Truncate text with ellipsis if too long"""
        if text is None:
            return ''
        text = str(text)
        if max_width <= 0:
            return ''
        ell = '...'
        ell_w = font.size(ell)[0]
        if ell_w > max_width:
            return ''
        if font.size(text)[0] <= max_width:
            return text
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi) // 2
            candidate = text[:mid].rstrip() + ell
            if font.size(candidate)[0] <= max_width:
                lo = mid + 1
            else:
                hi = mid
        res = text[:max(0, lo-1)].rstrip() + ell
        return res
    
    def render_panel_rows(rows, x, w, y0, h, page_key):
        row_h = 44
        view_top = y0
        view_bottom = y0 + h
        total = len(rows)
        max_scroll = max(0, total * row_h - h)
        s = scroll.get(page_key, 0)
        s = min(s, max_scroll)
        scroll[page_key] = s
        
        mouse_x, mouse_y = pygame.mouse.get_pos()
        tooltip = None
        
        for idx, r in enumerate(rows):
            if not (isinstance(r, (list, tuple)) and len(r) >= 2):
                continue
            uname = r[0]
            sc = r[1]
            yy = y0 + idx * row_h - s
            if yy + row_h < view_top or yy > view_bottom:
                continue
            
            # Row background
            rc = (40, 60, 90) if idx % 2 == 0 else (50, 70, 100)
            pygame.draw.rect(window, rc, (x + 6, yy - 4, w - 12, row_h - 4))
            pygame.draw.rect(window, (100, 150, 200), (x + 6, yy - 4, w - 12, row_h - 4), 1)
            
            # Rank, name, score
            rank_txt = font_rank.render(f"#{idx+1}", True, (255, 215, 0) if idx < 3 else (255,255,255))
            window.blit(rank_txt, (x + 12, yy))
            
            rank_area = 56
            score_area = 120
            name_max = max(20, w - rank_area - score_area)
            disp = truncate_text(font_rank, uname, name_max)
            name_txt = font_rank.render(disp, True, (255,255,255))
            name_rect = name_txt.get_rect(topleft=(x + rank_area, yy))
            window.blit(name_txt, name_rect)
            
            score_txt = font_score.render(str(sc), True, (255,255,255))
            score_rect = score_txt.get_rect(topright=(x + w - 14, yy))
            window.blit(score_txt, score_rect)
            
            if name_rect.collidepoint((mouse_x, mouse_y)):
                tooltip = uname
        return tooltip

    running = True
    while running:   
        # Handle events
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return 'quit'
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return 'menu'
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if ev.button == 4:  # wheel up
                    scroll[sub_page] = max(0, scroll.get(sub_page, 0) - 44)
                elif ev.button == 5:  # wheel down
                    scroll[sub_page] = scroll.get(sub_page, 0) + 44
            elif ev.type == pygame.MOUSEWHEEL:
                scroll[sub_page] = max(0, scroll.get(sub_page, 0) - ev.y * 44)
        
        # Draw background gradient
        for y in range(Game_Height):
            t = y / Game_Height
            r = int(30 + (90 - 30) * t)
            b = int(50 + (140 - 50) * t)
            pygame.draw.line(window, (r, 0, b), (0, y), (Game_Width, y))

        # Draw mode button
        pygame.draw.rect(window, (90,150,200), btn_award, border_radius=6)
        award_label = font_title.render('AWARDS', True, (255,255,255))
        window.blit(award_label, award_label.get_rect(center=btn_award.center))

        # Panel frame
        pygame.draw.rect(window, (18,28,48), panel_rect)

        # Render content
        tooltip = None
        if ui_mode == 'award':  # Fixed: use 'award' not 'awards'
            rows = database.get_awards(limit=50, game_mode=sub_page)
            tooltip = render_panel_rows(rows, panel_x, panel_w, panel_y, panel_h, sub_page)
        else:
            # Handle other modes if needed
            logged_user = session.get_user()
            ay = panel_y + 12

        # Instructions
        instr = font_small.render('Left/Right or click tabs to change page. Wheel to scroll.', True, (150,200,255))
        window.blit(instr, (Game_Width//2 - instr.get_width()//2, Game_Height - 36))

        # Tooltip
        if tooltip:
            tip_s = font_small.render(tooltip, True, (255,255,255))
            mx, my = pygame.mouse.get_pos()
            pygame.draw.rect(window, (0,0,0), (mx+8, my+8, tip_s.get_width()+8, tip_s.get_height()+8))
            window.blit(tip_s, (mx+12, my+12))

        pygame.display.update()
        clock.tick(60)