#login.py
import pygame
import math
from constants import *

# === MAKE ANIMATION VARIABLES GLOBAL TO THE MODULE ===
bg_x1 = 0
bg_x2 = Game_Width
bird_frame = 0
bird_animation_timer = 0
bird_bounce_offset = 0

def login_menu(window, assets, clock):
    global bg_x1, bg_x2, bird_frame, bird_animation_timer, bird_bounce_offset
    
    font = pygame.font.Font("FONT/flappy-font.ttf", 44)
    small_font = pygame.font.Font("FONT/flappy-font.ttf", 28)
    tiny_font = pygame.font.Font("FONT/flappy-font.ttf", 18)

    def draw_text(text, font, color, shadow, surface, x, y):
        shadow_obj = font.render(text, True, shadow)
        shadow_rect = shadow_obj.get_rect(center=(x + 2, y + 2))
        surface.blit(shadow_obj, shadow_rect)
        
        text_obj = font.render(text, True, color)
        text_rect = text_obj.get_rect(center=(x, y))
        surface.blit(text_obj, text_rect)

    # === CONSTANTS ONLY ===
    bg_speed = 1
    bird_animation_speed = 15
    bird_bounce_speed = 0.01  
    bird_bounce_range = 5
    bird_x = Game_Width // 2
    bird_y = Game_Height // 3

    while True:
        click = False
        music_toggled = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    music_toggled = True

        # === UPDATE ANIMATION ===
        bg_x1 -= bg_speed
        bg_x2 -= bg_speed
        
        if bg_x1 <= -Game_Width:
            bg_x1 = bg_x2 + Game_Width
        if bg_x2 <= -Game_Width:
            bg_x2 = bg_x1 + Game_Width

        bird_animation_timer += 1
        if bird_animation_timer >= bird_animation_speed:
            bird_animation_timer = 0
            bird_frame = (bird_frame + 1) % 2
        
        bird_bounce_offset = math.sin(pygame.time.get_ticks() * bird_bounce_speed) * bird_bounce_range

        # --- DRAW EVERYTHING ---
        window.blit(assets["bg"], (bg_x1, 0))
        window.blit(assets["bg"], (bg_x2, 0))

        current_bird_img = assets["bird1"] if bird_frame == 0 else assets["bird2"]
        bird_rect = current_bird_img.get_rect(center=(bird_x, bird_y + bird_bounce_offset))
        window.blit(current_bird_img, bird_rect)

        draw_text("Russel In", font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 100)
        draw_text("The Wonderland", font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 150)

        mx, my = pygame.mouse.get_pos() 
        button_size = 28

        # Define LOGIN and SIGNUP button rects
        login_rect = pygame.Rect(Game_Width//2 - 70, 250, 140, 40)
        signup_rect = pygame.Rect(Game_Width//2 - 70, 310, 140, 40)
        quit_rect = pygame.Rect(Game_Width//2 - 70, 370, 140, 40)

        # LOGIN button
        if login_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 200, 100), login_rect, border_radius=8)
            pygame.draw.rect(window, (50, 150, 50), login_rect, 3, border_radius=8)
            if click:
                from auth import auth_menu
                result = auth_menu(window, assets, clock)
                if result == "logged_in":
                    return "main_menu"  # Return to main program flow after successful login
        else:
            pygame.draw.rect(window, (80, 180, 80), login_rect, border_radius=8)
            pygame.draw.rect(window, (50, 150, 50), login_rect, 3, border_radius=8)
        
        draw_text("LOGIN", small_font, (255, 255, 255), (0, 0, 0), window, login_rect.centerx, login_rect.centery)

        # SIGNUP button
        if signup_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 150, 200), signup_rect, border_radius=8)
            pygame.draw.rect(window, (50, 100, 150), signup_rect, 3, border_radius=8)
            if click:
                from auth import signup_menu
                result = signup_menu(window, assets, clock)
                if result == "signed_up":
                    return "main_menu"  # Return to main program flow after successful signup
        else:
            pygame.draw.rect(window, (80, 130, 180), signup_rect, border_radius=8)
            pygame.draw.rect(window, (50, 100, 150), signup_rect, 3, border_radius=8)
        
        draw_text("SIGN UP", small_font, (255, 255, 255), (0, 0, 0), window, signup_rect.centerx, signup_rect.centery)

        # QUIT button
        if quit_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (200, 100, 100), quit_rect, border_radius=8)
            pygame.draw.rect(window, (150, 50, 50), quit_rect, 3, border_radius=8)
            if click:
                pygame.quit()
                exit()
        else:
            pygame.draw.rect(window, (180, 80, 80), quit_rect, border_radius=8)
            pygame.draw.rect(window, (150, 50, 50), quit_rect, 3, border_radius=8)
        
        draw_text("QUIT", small_font, (255, 255, 255), (0, 0, 0), window, quit_rect.centerx, quit_rect.centery)

        pygame.display.update()
        clock.tick(60)

        # RETURN AFTER FRAME COMPLETE
        if music_toggled:
            return "toggle_music"