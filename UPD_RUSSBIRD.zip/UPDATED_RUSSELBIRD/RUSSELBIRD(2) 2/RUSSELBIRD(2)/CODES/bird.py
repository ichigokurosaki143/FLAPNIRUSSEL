#bird_.py

import pygame
from constants import bird_x, bird_y, bird_w, bird_h

class Bird(pygame.Rect):
    def __init__(self, bird_images):
        super().__init__(bird_x, bird_y, bird_w, bird_h)
        self.bird_images = bird_images
        self.is_flapping = False
        self.flap_timer = 0
        self.current_img = bird_images["bird1"]
        self.angle = 0  # rotation angle
        self.velocity_y = 0  # track vertical velocity
    
    def start_flap(self):
        self.is_flapping = True
        self.flap_timer = 8
        self.current_img = self.bird_images["bird2"]
    
    def update_animation(self):
        if self.is_flapping:
            self.flap_timer -= 1
            if self.flap_timer <= 0:
                self.is_flapping = False
                self.current_img = self.bird_images["bird1"]
    
    def update_rotation(self, velocity_y):
        # Update rotation based on vertical velocity
        self.velocity_y = velocity_y
        
        # Kapag tumatalon (negative velocity), umaangat ang nguso
        if velocity_y < -5:
            self.angle = 25  # 25 degrees pataas
        # Kapag bumabagsak (positive velocity), bumababa ang nguso
        elif velocity_y > 5:
            self.angle = -25  # 25 degrees pababa
        # Kapag steady, balik sa normal
        else:
            self.angle = 0
    
    def get_rotated_image(self):
        # Return rotated image
        return pygame.transform.rotate(self.current_img, self.angle)