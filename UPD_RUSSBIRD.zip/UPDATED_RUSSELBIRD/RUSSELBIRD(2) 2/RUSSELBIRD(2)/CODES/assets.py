#assets_.py

import pygame
import os
import sys

# Add the current directory to the path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from constants import Game_Width, Game_Height, bird_w, bird_h, pipes_w, pipes_h

# Get the directory where this script is located and go up one level to RUSSELBIRD(2)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_assets():
    # === IMAGES ===

    # Import background image
    bg = pygame.image.load(os.path.join(BASE_DIR, "IMAGES/flappybirdbg.png")).convert_alpha()
    bg = pygame.transform.scale(bg, (Game_Width, Game_Height))

    # Import ground image
    ground = pygame.image.load(os.path.join(BASE_DIR, "IMAGES/ground.png")).convert_alpha()
    ground = pygame.transform.scale(ground, (Game_Width, 100))
    
    # Import bird images 
    bird1 = pygame.image.load(os.path.join(BASE_DIR, "IMAGES/bird1.png")).convert_alpha()
    bird1 = pygame.transform.scale(bird1, (bird_w, bird_h))

    bird2 = pygame.image.load(os.path.join(BASE_DIR, "IMAGES/bird2.png")).convert_alpha()
    bird2 = pygame.transform.scale(bird2, (bird_w, bird_h))

    # Import pipe images
    top_pipe = pygame.image.load(os.path.join(BASE_DIR, "IMAGES/top.png")).convert_alpha()
    top_pipe = pygame.transform.scale(top_pipe, (pipes_w, pipes_h))

    # Import bottom pipe image
    bottom_pipe = pygame.image.load(os.path.join(BASE_DIR, "IMAGES/bottom.png")).convert_alpha()
    bottom_pipe = pygame.transform.scale(bottom_pipe, (pipes_w, pipes_h))


    
    # === SOUNDS ===   
    flap = pygame.mixer.Sound(os.path.join(BASE_DIR, "SFX/sfx_wing.wav"))
    point = pygame.mixer.Sound(os.path.join(BASE_DIR, "SFX/sfx_point.wav"))
    hit = pygame.mixer.Sound(os.path.join(BASE_DIR, "SFX/sfx_hit.wav"))
    swoosh = pygame.mixer.Sound(os.path.join(BASE_DIR, "SFX/sfx_swooshing.wav"))
    die = pygame.mixer.Sound(os.path.join(BASE_DIR, "SFX/sfx_die.wav"))

    return {
        "bg": bg,
        "ground": ground,
        "bird1": bird1,  
        "bird2": bird2,  
        "top_pipe": top_pipe,
        "bottom_pipe": bottom_pipe,
        "flap": flap,
        "point": point,
        "hit": hit,
        "swoosh": swoosh,
        "die": die
    }