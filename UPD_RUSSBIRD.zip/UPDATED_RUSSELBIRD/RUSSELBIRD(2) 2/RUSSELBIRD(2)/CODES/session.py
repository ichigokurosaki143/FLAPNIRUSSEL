# session.py
# Simple in-memory session helper for the game UI
_current_user = None

def set_user(username: str | None):
    global _current_user
    _current_user = username


def get_user():
    return _current_user


def logout():
    """Clear the current session user."""
    set_user(None)
