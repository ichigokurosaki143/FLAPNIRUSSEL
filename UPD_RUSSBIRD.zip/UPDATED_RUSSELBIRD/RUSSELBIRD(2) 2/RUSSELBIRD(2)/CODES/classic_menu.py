# classic_menu.py

import pygame
import math
from constants import *
from game_mode_menu import *

bg_x1 = 0
bg_x2 = Game_Width
bird_frame = 0
bird_animation_timer = 0
bird_bounce_offset = 0

def classic_menu (window, assets, clock):
    global bg_x1, bg_x2, bird_frame, bird_animation_timer, bird_bounce_offset
    
    font_title = pygame.font.Font ("FONT/flappy-font.ttf", 40)
    font_text = pygame.font.Font ("FONT/flappy-font.ttf", 23)
    font_small = pygame.font.Font ("FONT/flappy-font.ttf", 18)
    font_big = pygame.font.Font ("FONT/flappy-font.ttf", 55)

    def draw_text (text, font, color, shadow, surface, x, y):
        shadow_obj = font.render (text, True, shadow)
        shadow_rect = shadow_obj.get_rect (center = (x + 2, y + 2))
        surface.blit (shadow_obj, shadow_rect)
        
        text_obj = font.render (text, True, color)
        text_rect = text_obj.get_rect (center=(x, y))
        surface.blit (text_obj, text_rect)

    # === CONSTANTS ONLY ===
    bg_speed = 1
    bird_animation_speed = 15
    bird_bounce_speed = 0.01  
    bird_bounce_range = 5
    button_width = 150
    button_height = 50

    while True:
        click = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True

        # === UPDATE ANIMATION (USING GLOBAL VARIABLES) ===
        bg_x1 -= bg_speed
        bg_x2 -= bg_speed
        
        if bg_x1 <= -Game_Width:
            bg_x1 = bg_x2 + Game_Width
        if bg_x2 <= -Game_Width:
            bg_x2 = bg_x1 + Game_Width

        bird_animation_timer += 1
        if bird_animation_timer >= bird_animation_speed:
            bird_animation_timer = 0
            bird_frame = (bird_frame + 1) % 2
        
        bird_bounce_offset = math.sin (pygame.time.get_ticks() * bird_bounce_speed) * bird_bounce_range

        # --- DRAW EVERYTHING ---
        window.blit(assets ["bg"], (bg_x1, 0))
        window.blit(assets ["bg"], (bg_x2, 0))

        draw_text("CLASSIC", font_big, (119, 221, 119), (19, 121, 19), window, Game_Width//2, 80)

        current_bird_img = assets["bird1"] if bird_frame == 0 else assets ["bird2"]
        bird_rect = current_bird_img.get_rect(center = (bird_x, bird_y + bird_bounce_offset))
        window.blit(current_bird_img, bird_rect)


        # Draw classic board
        board_w, board_h = 280, 250
        board_x, board_y = (Game_Width - board_w) /2, (Game_Height - board_h) //2 - 50


        pygame.draw.rect (window, (245, 222, 179), (board_x, board_y, board_w, board_h), border_radius = 15)
        pygame.draw.rect (window, (222, 184, 135), (board_x, board_y, board_w, board_h), 4, border_radius = 15)


        draw_text ("HOW TO PLAY", font_title, (255, 255, 255), (155, 155, 155), window, Game_Width //2, board_x + 135)

        instructions = [
            "No difficulty increase",
            "Pipes does not move"
        ]

        # Draw Instructions

        y_pos = board_y + 120
        for line in instructions:
            
            if line:
                draw_text (line, font_text, (200, 255, 200), (50, 50, 50), window, Game_Width //2, y_pos)
                y_pos += 25

            else:
                y_pos += 10

        mx, my = pygame.mouse.get_pos ()
        play_rect = pygame.Rect (Game_Width //2 - button_width //2, board_y + board_h + 20, button_width, button_height)
        
        # Classic button
        if play_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (100, 200, 100), play_rect, border_radius = 10)
            pygame.draw.rect (window, (50, 150, 50), play_rect, 3, border_radius = 10)
            if click:
                return "classic"
        
        else:
            pygame.draw.rect (window, (80, 180, 80), play_rect, border_radius = 10)
            pygame.draw.rect (window, (50, 150, 50), play_rect, 3, border_radius = 10)
        
        draw_text ("PLAY", font_small, (255, 255, 255), (0, 0, 0), window, play_rect.centerx, play_rect.centery)
        

        back_rect = pygame.Rect(Game_Width // 2 - button_width // 2, play_rect.bottom + 20, button_width, button_height)
        if back_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (200, 100, 100), back_rect, border_radius = 10)
            pygame.draw.rect (window, (150, 50, 50), back_rect, 3, border_radius = 10)
            if click:
                return "back"
        
        else:
            pygame.draw.rect (window, (180, 80, 80), back_rect, border_radius = 8)
            pygame.draw.rect (window, (150, 50, 50), back_rect, 3, border_radius = 8)
        
        draw_text("BACK", font_small, (255, 255, 255), (0, 0, 0), window, back_rect.centerx, back_rect.centery)
        
        pygame.display.update()
        clock.tick(60)


        
        