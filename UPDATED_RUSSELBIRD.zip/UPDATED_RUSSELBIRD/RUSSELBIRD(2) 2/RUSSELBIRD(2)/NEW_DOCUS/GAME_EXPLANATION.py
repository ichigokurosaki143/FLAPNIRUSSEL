"""
================================================================================
RUSSEL IN THE WONDERLAND - COMPLETE CODE ARCHITECTURE ANALYSIS
================================================================================

This script provides a detailed explanation of how the game works.

OVERVIEW:
---------
Russel in the Wonderland is a Flappy Bird-style arcade game built with Pygame-CE.
Players navigate a bird character through scrolling pipes with increasing difficulty.

Screen: 360x640 pixels | Target FPS: 60 | Python: 3.14.0+

================================================================================
GAME MODULE BREAKDOWN
================================================================================

1. MAIN.PY - ENTRY POINT & MAIN LOOP
   ──────────────────────────────────
   Purpose: Initialize game, manage program flow, implement core game loop
   
   Key Functions:
   - run_game(): Main 60 FPS game loop with physics and collision detection
   
   Game State Variables:
   - velocity_x: Horizontal pipe speed (-2 to -4.3 based on difficulty)
   - velocity_y: Vertical bird position change (affected by gravity and jumps)
   - gravity: Downward acceleration (0.4 to 0.5)
   - jump_strength: Upward impulse when jumping (-6 to -7.2)
   - score: Current game points
   - high_score: Best score in current session
   - game_over: Boolean flag for collision/boundary state
   
   Input Handling:
   - SPACE/W/UP: Jump (set velocity_y to jump_strength)
   - P/ESC: Toggle pause menu
   - M: Toggle background music
   - Q: Quit to menu (only during game over)
   
   Loop Cycle (repeats 60 times per second):
   1. Process events (keyboard, timers)
   2. Update physics (apply gravity, move pipes)
   3. Check collisions (ground, ceiling, pipes)
   4. Update difficulty if score changed
   5. Render all graphics
   6. Update display
   7. Cap frame rate at 60 FPS

2. CONFIG.PY - GAME SETTINGS & DIFFICULTY
   ───────────────────────────────────────
   Purpose: Centralize configuration and difficulty progression
   
   Game Dimensions:
   - Screen: 360x640 pixels
   - Bird: 34x24 pixels
   - Pipes: 64x512 pixels
   - Gap: ~123 pixels
   
   Difficulty Tiers (auto-adjusted based on score):
   
   Score 0-4:
     - Pipe Speed: -2.0 pixels/frame
     - Gravity: 0.40
     - Jump Strength: -6.0
     - Oscillation: Disabled
   
   Score 5-9:
     - Pipe Speed: -2.8 (40% faster)
     - Gravity: 0.42 (5% stronger)
     - Jump Strength: -6.3 (5% more power)
     - Oscillation: Disabled
   
   Score 10-14: *** MAJOR MILESTONE ***
     - Pipe Speed: -3.3 (65% faster than start)
     - Gravity: 0.45 (12.5% stronger)
     - Jump Strength: -6.6 (10% more power)
     - Oscillation: ENABLED (pipes move up/down)
     - Osc Frequency: 0.0026
     - Osc Amplitude: 34 pixels
   
   Score 15-19:
     - Pipe Speed: -3.8 (90% faster)
     - Gravity: 0.48 (20% stronger)
     - Jump Strength: -6.9 (15% more power)
     - Oscillation: Faster
   
   Score 20+:
     - Pipe Speed: -4.3 (115% faster)
     - Gravity: 0.50 (25% stronger)
     - Jump Strength: -7.2 (20% more power)
     - Oscillation: Fastest

3. CONSTANTS.PY - STATIC VALUES
   ─────────────────────────────
   Purpose: Define game constants used across all modules
   
   Contains:
   - Screen dimensions (Game_Width, Game_Height)
   - Bird properties (bird_x, bird_y, bird_w, bird_h)
   - Pipe properties (pipes_x, pipes_y, pipes_w, pipes_h)
   - Opening space between pipes (Opening_Space)
   - Oscillation parameters (Pipe_Osc_Amp, Pipe_Osc_Freq)

4. ASSETS.PY - RESOURCE LOADING
   ────────────────────────────
   Purpose: Load all game images and sounds
   
   Function: load_assets()
   - Loads 8 image sprites (background, ground, bird frames, pipes, icons)
   - Loads 5 sound effects (wing, point, hit, swoosh, die)
   - Applies scaling to fit game dimensions
   - Returns dictionary of all assets
   
   Path Resolution:
   - Calculates BASE_DIR as parent of CODES folder
   - Uses os.path.join() for cross-platform compatibility
   - Allows running from any working directory

5. BIRD.PY - BIRD CLASS & ANIMATION
   ──────────────────────────────────
   Purpose: Manage bird sprite, animation state, and rotation
   
   Class: Bird(pygame.Rect)
   Inherits from pygame.Rect for collision detection
   
   Attributes:
   - bird_images: Dict with 2 sprite frames
   - is_flapping: Boolean animation state
   - flap_timer: Counter (8 frames per flap)
   - current_img: Currently displayed sprite
   - angle: Rotation angle (-25 to 25 degrees)
   - velocity_y: Current vertical movement
   
   Methods:
   - start_flap(): Trigger wing flap animation
   - update_animation(): Progress animation frames
   - update_rotation(velocity_y): Calculate rotation based on velocity
   - get_rotated_image(): Return sprite with current rotation
   
   Animation Rules:
   - Resting: bird1 sprite, 0° angle
   - Flapping: bird2 sprite, held for 8 frames
   - Rising: 25° angle (nose up) when velocity < -5
   - Falling: -25° angle (nose down) when velocity > 5
   - Neutral: 0° angle when -5 ≤ velocity ≤ 5

6. PIPES.PY - PIPE CLASS
   ─────────────────────
   Purpose: Define pipe obstacle
   
   Class: Pipe(pygame.Rect)
   Inherits from pygame.Rect for collision detection
   
   Attributes:
   - img: Pipe sprite image
   - passed: Flag for scoring (prevents double-scoring)
   - base_y: Initial Y position (used for oscillation)
   - spawn_time: Creation timestamp (for oscillation calculation)
   - phase_offset: Unique sine wave offset (0 to 2π)
   
   Purpose of phase_offset:
   Different pipe pairs oscillate at different phases, creating
   varied and unpredictable obstacle patterns

7. GAME_FUNCTIONS.PY - CORE GAME LOGIC
   ────────────────────────────────────
   Purpose: Implement physics, collision detection, rendering
   
   Function: move(bird, pipes, sounds, game_state)
   ────────────────────────────────────────────
   Returns: Updated game state
   
   Processes:
   1. Difficulty Update:
      - Check current score
      - Update velocity_x, gravity, jump_strength based on tier
      - Update oscillation parameters
   
   2. Physics:
      - Apply gravity: velocity_y += gravity
      - Move bird: bird.y += velocity_y
      - Move pipes: pipe.x += velocity_x
      - Calculate oscillation offset using sine function
   
   3. Boundary Checking:
      - Bird can't go above y=0 (ceiling)
      - Bird collides with ground at y = 640 - 62.5 - bird_height
   
   4. Pipe Movement:
      - Each pipe moves left by velocity_x per frame
      - When pipe.x < -64, remove from list
   
   5. Pipe Oscillation (when score ≥ 10):
      offset = sin(elapsed_time * frequency + phase_offset) * amplitude
      pipe.y = base_y + offset
      Creates up/down movement pattern
   
   6. Collision Detection:
      - bird.colliderect(top_pipe) → collision
      - bird.colliderect(bottom_pipe) → collision
      - If collision: game_over = True, play sounds
   
   7. Scoring:
      - When bird.x > pipe.x + pipe_width (passed through):
        * If not pipe.passed:
          * score += 1
          * Play point sound
          * Mark pipe.passed = True
   
   8. Cleanup:
      - Remove off-screen pipes to free memory
   
   Function: draw(window, bird, pipes, assets, score, high_score, game_over, ...)
   ───────────────────────────────────────────────────────────────────────────
   Renders all game elements in proper order:
   
   1. Draw background (parallax scroll at 60% speed)
      - window.blit(assets["bg"], (bg_x1, 0))
      - window.blit(assets["bg"], (bg_x2, 0))
   
   2. Draw all pipes
      - for pipe in pipes: window.blit(pipe.img, pipe)
   
   3. Draw bird with rotation
      - rotated_bird = bird.get_rotated_image()
      - Adjust rect to center on bird position
      - window.blit(rotated_bird, bird_rect)
   
   4. Draw scrolling ground
      - Similar parallax approach as background
   
   5. Draw score (top center)
      - Only display if not game_over
      - Large white text with black shadow
   
   6. Draw game over screen (if active)
      - Beige scoreboard background
      - Display current score and high score
      - Show restart/quit instructions
   
   Rendering Order is Important:
   - Background first (farthest)
   - Pipes
   - Bird
   - Ground (closes to camera)
   - Score UI (overlay)

8. MAIN_MENU.PY - MENU INTERFACE
   ──────────────────────────────
   Purpose: Display interactive start menu
   
   Features:
   - Animated scrolling background
   - Bouncing bird animation
   - Three interactive buttons: PLAY, HELP, QUIT
   - Music toggle (M key)
   - Hover effects on buttons
   
   Animations:
   - Background: Scrolls 1 pixel/frame (creates movement)
   - Bird: Bounces using sine wave
     offset = sin(time * 0.01) * 5  (±5 pixel range)
   - Bird Frame: Alternates between bird1/bird2 every 15 frames
   
   Button Interaction:
   - Get mouse position
   - Check if mouse inside button rectangle
   - If hovering: Draw brighter button color
   - If clicked: Return action string

9. PAUSE_MENU.PY - PAUSE SCREEN
   ─────────────────────────────
   Purpose: Pause game when P or ESC pressed
   
   Features:
   - Semi-transparent overlay (128 alpha)
   - Shows frozen game in background
   - Two buttons: RESUME, EXIT TO MENU
   - Resume via P/ESC key or RESUME button
   
   Visual Design:
   - Dark overlay dims background
   - High contrast text
   - Clear button feedback

10. HELP.PY - INSTRUCTIONS SCREEN
    ──────────────────────────────
    Purpose: Display game controls and rules
    
    Content:
    - Title: "HOW TO PLAY"
    - Controls list:
      * SPACE / W / UP - Jump
      * P / ESC - Pause Game
      * M - Toggle Music
      * Q - Quit to Menu
    - Back button (B key or click)
    
    Design:
    - Same scrolling background as menu
    - Same bouncing bird animation
    - Beige instruction board
    - Professional typography

11. TRANSITION.PY - VISUAL EFFECTS
    ───────────────────────────────
    Purpose: Create fade transitions between screens
    
    Function: fade_effect(window, duration=200)
    
    Process:
    - Fade OUT: Alpha goes 0→255 (blacken screen)
      * 30 steps over ~200ms
      * Creates smooth darkening effect
    
    - Fade IN: Alpha goes 255→0 (lighten screen)
      * 30 steps over ~200ms
      * Returns to normal screen
    
    Used for:
    - Menu → Game transitions
    - Game Over → Menu
    - Menu → Help → Menu

================================================================================
PHYSICS ENGINE EXPLANATION
================================================================================

GRAVITY & JUMPING:
──────────────────
Each frame, these calculations occur:

    # Apply gravity (constant acceleration down)
    velocity_y += gravity
    
    # Move bird based on velocity
    bird.y += velocity_y
    
    # Boundary check
    if bird.y >= ground_level or bird.y <= 0:
        game_over = True

Example of a jump:
    Frame 0: Jump key pressed → velocity_y = -6 (upward)
    Frame 1: velocity_y = -6 + 0.4 = -5.6, bird rises
    Frame 2: velocity_y = -5.6 + 0.4 = -5.2, bird rises slower
    ...
    Frame 15: velocity_y ≈ 0, bird reaches peak
    Frame 16: velocity_y = 0.4 (positive, bird falls)
    Frame 17: velocity_y = 0.8 (falling faster)
    
Terminal velocity occurs when gravity force equals jump effect.

PIPE OSCILLATION:
─────────────────
When score ≥ 10, pipes begin moving vertically:

    elapsed = current_time - spawn_time
    offset = sin(elapsed * frequency + phase_offset) * amplitude
    
    Example with defaults:
    - amplitude = 34 pixels (max deviation)
    - frequency = 0.0026 (controls speed of oscillation)
    - phase_offset = random(0 to 2π)
    
    Result: Pipes move smoothly between (base_y - 34) to (base_y + 34)
    Creates predictable but challenging pattern

SCROLLING PARALLAX:
───────────────────
Background appears to move slower than foreground:

    background_speed = velocity_x * 0.6 (60% of pipe speed)
    ground_speed = velocity_x * 1.0 (100% of pipe speed)
    
    This creates illusion of depth:
    - Distant background moves slowly
    - Close ground moves at normal speed
    - Foreground pipes move at base speed

================================================================================
GAME LOOP EXECUTION (Per Frame at 60 FPS = 16.67ms per frame)
================================================================================

STEP 1: EVENT HANDLING (Keyboard, Timers)
──────────────────────────────────────────
for event in pygame.event.get():
    if event.type == pygame.QUIT:
        exit()
    
    if event.type == PIPE_CREATE_TIMER:  # Every 2000ms
        create_pipe_pair()  # Spawn new pipe at right edge
    
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_SPACE:
            velocity_y = jump_strength  # Jump!
            bird.start_flap()
        elif event.key == pygame.K_p:
            show_pause_menu()
        elif event.key == pygame.K_m:
            toggle_music()

STEP 2: UPDATE PHYSICS (if not game_over)
──────────────────────────────────────────
bird.update_animation()
bird.update_rotation(velocity_y)
velocity_y, score, game_over, ... = move(bird, pipes, assets, game_state)

Inside move():
- velocity_y += gravity
- bird.y += velocity_y
- For each pipe:
    * pipe.x += velocity_x
    * if score >= 10:
        * Calculate oscillation
        * pipe.y = base_y + offset
    * Check collisions
    * Check scoring

STEP 3: BACKGROUND SCROLLING
────────────────────────────
bg_x1 += velocity_x * 0.6
bg_x2 += velocity_x * 0.6
if bg_x1 < -360:
    bg_x1 = bg_x2 + 360  # Loop background

ground_x1 += ground_speed
ground_x2 += ground_speed
# Same looping logic

STEP 4: RENDERING
─────────────────
draw(window, bird, pipes, assets, score, high_score, game_over, ...)

Order:
1. Background (parallax)
2. Pipes
3. Bird (with rotation)
4. Ground (parallax)
5. Score text
6. If game_over: Game over screen

STEP 5: DISPLAY UPDATE & FRAME CAP
──────────────────────────────────
pygame.display.update()  # Render to screen
clock.tick(60)           # Cap at 60 FPS (16.67ms per frame)

================================================================================
COLLISION DETECTION SYSTEM
================================================================================

Three collision scenarios:

1. BOUNDARY COLLISIONS:
   ground_y = 640 - 62.5 - 24 = 553.5
   if bird.y >= 553.5 or bird.y <= 0:
       game_over = True

2. PIPE COLLISIONS:
   if bird.colliderect(top_pipe):
       game_over = True
   if bird.colliderect(bottom_pipe):
       game_over = True
   
   Uses pygame.Rect collision detection (fast, built-in)

3. SCORING (SAFE PASSAGE):
   if not pipe.passed and bird.x > pipe.x + 64:
       score += 1
       pipe.passed = True
       play_point_sound()

When game_over triggered:
- Play hit + die sounds
- Compare score vs high_score
- Set game_over flag to True
- Next frame renders game over screen
- Player can restart (SPACE) or quit (Q)

================================================================================
DIFFICULTY PROGRESSION EXAMPLE
================================================================================

Player starts at Score 0:
│
├─ Easy Phase (Score 0-4)
│  ├─ Pipes move at -2.0 px/frame
│  ├─ Gravity: 0.40 (easy to control)
│  ├─ No oscillation
│  └─ Player learns controls
│
├─ Medium Phase (Score 5-9)
│  ├─ Pipes move at -2.8 px/frame (40% faster)
│  ├─ Gravity: 0.42 (slightly harder)
│  ├─ Still no oscillation
│  └─ Player adapts to pace
│
├─ MAJOR MILESTONE (Score ≥ 10)
│  ├─ Pipes move at -3.3 px/frame (65% faster)
│  ├─ PIPES BEGIN OSCILLATING
│  ├─ Gaps move up/down unpredictably
│  ├─ Game changes from "timed" to "reactive"
│  └─ This is where most players fail
│
├─ Hard Phase (Score 15-19)
│  ├─ Pipes move at -3.8 px/frame (90% faster)
│  ├─ Oscillation becomes faster
│  └─ Requires precise timing
│
└─ Extreme Phase (Score 20+)
   ├─ Pipes move at -4.3 px/frame (115% faster!)
   ├─ Maximum oscillation speed
   └─ Only for skilled players

The jump power also increases slightly to compensate for stronger gravity,
but pipes move much faster, making it legitimately harder.

================================================================================
KEY GAME MECHANICS SUMMARY
================================================================================

1. INFINITE PROCEDURAL GENERATION
   - Pipes spawn every 2 seconds
   - Random vertical position (within constraints)
   - Unique oscillation phase per pair
   - Creates endless gameplay

2. SKILL-BASED SCORING
   - Must navigate between pipes
   - No luck involved
   - Pure timing and reaction
   - Scores measure skill level

3. PROGRESSIVE DIFFICULTY
   - Auto-scales based on performance
   - Smooth difficulty curve
   - Major change at milestone (score 10)
   - Keeps players challenged

4. VISUAL FEEDBACK
   - Bird animation shows state
   - Rotation indicates velocity
   - Score displays prominently
   - Sound effects reinforce actions

5. STATE PERSISTENCE
   - High score saved during session
   - Encourages repeated attempts
   - Competitive motivation

================================================================================
CODE QUALITY & ARCHITECTURE
================================================================================

STRENGTHS:
✓ Modular design (separate files for UI, physics, rendering)
✓ Configuration centralized (easy to tweak difficulty)
✓ Clean asset loading (proper path resolution)
✓ Professional UI (menus, pause, help screens)
✓ Sound design (feedback for actions)
✓ Smooth animations (parallax, bird flapping)
✓ Responsive controls (immediate feedback)

POTENTIAL IMPROVEMENTS:
⊙ Save high score to file (currently session-only)
⊙ Add difficulty selection menu
⊙ Leaderboard system
⊙ Power-ups/special items
⊙ Multiple bird skins
⊙ Achievement system
⊙ Statistics tracking

PERFORMANCE:
• 60 FPS target achieved
• Low memory footprint
• Efficient collision detection
• No frame skipping observed
• Smooth scrolling parallax

================================================================================
CONCLUSION
================================================================================

Russel in the Wonderland demonstrates professional game development practices:

✓ Clean Architecture: Separation of concerns (UI, physics, rendering, config)
✓ User Experience: Intuitive menus, responsive controls, visual feedback
✓ Game Design: Progressive difficulty, skill-based challenges
✓ Code Quality: Modular, maintainable, scalable codebase
✓ Polish: Animations, sounds, transitions, high scores

The game is a fully functional arcade experience suitable for casual players,
with code that's maintainable and extensible for future enhancements.

================================================================================
"""

# EXECUTION STARTS HERE
if __name__ == "__main__":
    print(__doc__)
    print("\n" + "="*80)
    print("To run the game:")
    print("="*80)
    print("cd \"c:\\Users\\preci\\OneDrive\\RUSSELBIRD(2) 2\\RUSSELBIRD(2)\"")
    print("python CODES/main.py")
    print("="*80)
    print("\nControls:")
    print("  SPACE/W/UP - Jump")
    print("  P/ESC      - Pause/Resume")
    print("  M          - Toggle Music")
    print("  Q          - Quit to Menu (Game Over only)")
    print("="*80)
