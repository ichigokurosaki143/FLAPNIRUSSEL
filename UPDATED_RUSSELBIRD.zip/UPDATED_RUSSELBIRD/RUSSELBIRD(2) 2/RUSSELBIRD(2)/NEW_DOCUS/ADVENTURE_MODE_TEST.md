# ADVENTURE MODE TESTING GUIDE - 3 POINTS TO VICTORY

## Changes Made
- Victory condition changed from **30 points → 3 points**
- Game mode menu updated to show "Reach 3 points to pass the tower! (Testing)"
- Easier to test the full adventure experience quickly

---

## How to Test Adventure Mode Victory

### Step 1: Launch the Game
```powershell
cd "c:\Users\preci\OneDrive\RUSSELBIRD(2) 2\RUSSELBIRD(2)"
python CODES/main.py
```

### Step 2: Navigate to Game Mode Menu
1. Click **PLAY** button on main menu
2. You'll see **GAME MODE SELECTION** menu
3. Click **ADVENTURE MODE** button (blue button)

### Step 3: Play to 3 Points
1. Jump using **SPACE**, **W**, or **UP arrow**
2. Navigate through the pipes
3. Get **3 points** to trigger victory
4. When you reach 3 points:
   - Fade transition effect
   - Tower victory screen appears
   - "CONGRATULATIONS!" message displays
   - Tower image/placeholder appears
   - "YOU PASSED THE TOWER!" message
   - Final score (3) displayed
   - Continue with SPACE or click

### Step 4: Return to Menu
1. Press **SPACE** or click anywhere on victory screen
2. Returns to main menu
3. Can play again in different mode

---

## What to Look For

✓ **Mode Selection Screen**
  - Title visible
  - Two buttons (Classic/Adventure)
  - Descriptions updated with "3 points" text
  - Animated background and bird

✓ **Adventure Mode Gameplay**
  - Difficulty increases normally
  - Pipes move and obstacles appear
  - Score counter increases
  - No issues with scoring

✓ **Victory Trigger at 3 Points**
  - Game stops immediately at 3 points
  - Fade transition effect plays
  - Victory screen displays

✓ **Victory Screen**
  - "CONGRATULATIONS!" text visible
  - "YOU PASSED THE TOWER!" message
  - Final score (3) shown
  - Tower display (image or placeholder rectangle)
  - Continue instructions visible
  - Can continue with SPACE or mouse click

✓ **Return to Menu**
  - Returns cleanly to main menu
  - No errors or freezes
  - Can select modes again

---

## Testing Checklist

- [ ] Game launches successfully
- [ ] PLAY → Mode selection menu shows
- [ ] ADVENTURE MODE button works
- [ ] Menu shows "3 points" in description
- [ ] Game starts without errors
- [ ] First point scored successfully
- [ ] Second point scored
- [ ] Third point triggers victory immediately
- [ ] Fade effect plays
- [ ] Tower victory screen displays
- [ ] All text visible and readable
- [ ] Continue button/SPACE works
- [ ] Returns to menu successfully
- [ ] Can play again in different mode

---

## Expected Behavior Timeline

```
T=0s:  Game starts, Adventure mode selected
T=0-5s: First pipe passes
T=5-10s: Score = 1 point
T=10-15s: Second pipe passes
T=15-20s: Score = 2 points
T=20-25s: Third pipe passes
T=25s:  Score = 3 points → VICTORY TRIGGERED
T=26s:  Fade effect starts
T=27s:  Tower victory screen appears
T=27-35s: Victory screen displayed
T=35s:  SPACE pressed or clicked
T=36s:  Returns to main menu
```

---

## If Issues Occur

**Game Crashes:**
- Check if all files compiled: `python -m py_compile main.py game_mode_menu.py tower_victory.py`
- Look for syntax errors in terminal

**Victory Doesn't Trigger:**
- Verify score is actually reaching 3
- Check main.py line 127: `if game_mode == "adventure" and score >= 3:`

**Victory Screen Doesn't Display:**
- Check tower_victory.py file exists
- Verify FONT/flappy-font.ttf exists
- Check console for error messages

**Can't Return to Menu:**
- Press ESC or try clicking "Continue"
- Should return to main menu after a few seconds

---

## Notes

- Victory set to **3 points for easy testing**
- Once confirmed working, can be changed back to 30 for actual game
- No difficulty changes needed for this test
- Test focuses on Adventure mode victory flow

---

## Next Steps After Testing

Once confirmed working at 3 points:

1. Change victory point to desired value (e.g., 30)
   - Edit main.py line 127: `if game_mode == "adventure" and score >= 3:` → `score >= 30`
   - Edit game_mode_menu.py: Update description text

2. Add custom tower image
   - Place tower.png in IMAGES/ folder
   - tower_victory.py will auto-load it

3. Adjust difficulty if needed
   - Edit config.py for different difficulty progression

---

**Ready to test! Run the game and try to reach 3 points in Adventure mode!**

