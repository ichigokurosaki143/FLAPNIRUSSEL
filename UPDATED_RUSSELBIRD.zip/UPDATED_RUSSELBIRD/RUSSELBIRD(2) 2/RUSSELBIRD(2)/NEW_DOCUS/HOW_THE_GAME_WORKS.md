# 🐦 RUSSEL IN THE WONDERLAND - GAME ARCHITECTURE DOCUMENTATION

## Table of Contents
1. [Project Overview](#project-overview)
2. [File Structure](#file-structure)
3. [Game Flow Diagram](#game-flow-diagram)
4. [Module Breakdown](#module-breakdown)
5. [Game Physics & Mechanics](#game-physics--mechanics)
6. [Difficulty System](#difficulty-system)
7. [Key Features](#key-features)
8. [How to Run](#how-to-run)

---

## Project Overview

**Russel in the Wonderland** is a Flappy Bird-style game built with **Pygame-CE** (Community Edition). The game features:
- **Screen Resolution**: 360x640 pixels
- **Target FPS**: 60 frames per second
- **Language**: Python 3.14.0+
- **Framework**: Pygame-CE 2.5.6

The objective is to navigate a bird character (Russel) through oscillating pipes without collision, with increasing difficulty based on score.

---

## File Structure

```
RUSSELBIRD(2)/
├── CODES/
│   ├── main.py              # Entry point - Game initialization & main loop
│   ├── config.py            # Game configuration and difficulty settings
│   ├── constants.py         # Game constants and static values
│   ├── assets.py            # Asset loading (images, sounds)
│   ├── bird.py              # Bird class and animation logic
│   ├── pipes.py             # Pipe class definition
│   ├── game_functions.py    # Core game mechanics (move, draw, collision)
│   ├── main_menu.py         # Main menu UI with animations
│   ├── pause_menu.py        # Pause menu UI
│   ├── help.py              # Help/instructions screen
│   └── transition.py        # Fade transition effects
├── IMAGES/                  # Game sprites (background, pipes, bird, icons)
├── SFX/                     # Sound effects and background music
└── FONT/                    # Game fonts (flappy-font.ttf)
```

---

## Game Flow Diagram

```
┌─────────────────────────┐
│   Program Start         │
│   (main.py)            │
└────────────┬────────────┘
             │
             ▼
┌──────────────────────────┐
│  Initialize Pygame       │
│  Load Assets & Config    │
│  Load Background Music   │
└────────────┬─────────────┘
             │
             ▼
    ┌────────────────────┐
    │  MAIN MENU LOOP    │
    ├────────────────────┤
    │ • Show Title       │
    │ • Display Buttons  │
    │ • Handle Input     │
    └────────┬───────────┘
             │
    ┌────────┴────────────────────┬──────────────┬──────────┐
    │                             │              │          │
    ▼                             ▼              ▼          ▼
  PLAY                         HELP          QUIT      TOGGLE MUSIC
    │                             │
    │                             ▼
    │                        ┌──────────────┐
    │                        │  HELP SCREEN │
    │                        │  (Back key)  │
    │                        └──────┬───────┘
    │                               │
    │                               ▼
    │                        Return to Menu
    │
    ▼
┌────────────────────────────────────┐
│      GAME LOOP (run_game)          │
├────────────────────────────────────┤
│ 1. Handle Input (Jump, Pause, etc) │
│ 2. Update Game State               │
│ 3. Check Collisions                │
│ 4. Update Score & Difficulty       │
│ 5. Draw Everything                 │
│ 6. Cap FPS at 60                   │
└─────────────────┬──────────────────┘
                  │
        ┌─────────┴─────────────┐
        │                       │
        ▼                       ▼
   PAUSED (P/ESC)        GAME OVER (Collision)
        │                       │
        ├─ Resume              ├─ Restart (SPACE)
        └─ Exit to Menu        └─ Exit to Menu (Q)
```

---

## Module Breakdown

### 1. **main.py** - Entry Point & Game Loop
**Purpose**: Initialize the game and manage the main program flow.

**Key Components**:
- **Initialization**:
  - Creates pygame window (360x640)
  - Initializes mixer for sound
  - Loads all assets via `load_assets()`
  - Starts background music

- **run_game()** Function:
  - Contains the core 60 FPS game loop
  - Handles keyboard input for jumping, pausing, quitting
  - Updates bird position and animation
  - Detects pipe creation every 2 seconds
  - Manages game over state

- **Main Program Flow**:
  - Menu → Play/Help/Quit selection
  - Fade transitions between screens
  - Music toggle support

**Key Variables**:
```python
velocity_x = -2           # Horizontal pipe movement speed
velocity_y = 0            # Vertical bird movement
gravity = 0.4             # Downward acceleration
jump_strength = -6        # Upward impulse when jumping
Pipe_Osc_Freq = 0.002     # Pipe oscillation frequency
Pipe_Osc_Amp = 30         # Pipe oscillation amplitude
score = 0                 # Current game score
high_score = 0            # Best score achieved
```

**Game Loop Cycle (60 FPS)**:
1. Event handling (keyboard, quit)
2. Pipe creation timer (every 2000ms)
3. Bird animation update
4. Bird rotation based on velocity
5. Physics calculations (gravity, collision)
6. Screen rendering

---

### 2. **config.py** - Game Configuration

**Purpose**: Centralize all game settings and difficulty progression.

**Configuration Parameters**:

| Parameter | Value | Purpose |
|-----------|-------|---------|
| SCREEN_WIDTH | 360 | Game window width |
| SCREEN_HEIGHT | 640 | Game window height |
| BIRD_START_X | 45 | Bird initial X position |
| BIRD_START_Y | 320 | Bird initial Y position |
| BIRD_WIDTH | 34 | Bird sprite width |
| BIRD_HEIGHT | 24 | Bird sprite height |
| PIPE_WIDTH | 64 | Pipe sprite width |
| PIPE_HEIGHT | 512 | Pipe sprite height |
| PIPE_OPENING_SPACE | ~123 | Gap between pipes |
| PIPE_OSCILLATION_AMPLITUDE | 30 | Max pipe vertical movement |
| PIPE_OSCILLATION_FREQUENCY | 0.002 | How fast pipes oscillate |

**Difficulty Settings** - `get_difficulty_settings(score)`:

```
Score 0-4:    velocity_x=-2.0,   gravity=0.40, jump=-6.0,   osc_freq=0.0020, osc_amp=30
Score 5-9:    velocity_x=-2.8,   gravity=0.42, jump=-6.3,   osc_freq=0.0023, osc_amp=32
Score 10-14:  velocity_x=-3.3,   gravity=0.45, jump=-6.6,   osc_freq=0.0026, osc_amp=34
Score 15-19:  velocity_x=-3.8,   gravity=0.48, jump=-6.9,   osc_freq=0.0029, osc_amp=36
Score 20+:    velocity_x=-4.3,   gravity=0.50, jump=-7.2,   osc_freq=0.0032, osc_amp=38
```

**How Difficulty Works**:
- Pipes move FASTER (more negative velocity_x)
- Gravity becomes STRONGER (harder to stay up)
- Jump power increases to compensate
- Pipes oscillate MORE (trickier to navigate)

---

### 3. **constants.py** - Static Game Values

**Purpose**: Define immutable game constants used across modules.

**Contains**:
- Screen dimensions (Game_Width, Game_Height)
- Bird properties (bird_x, bird_y, bird_w, bird_h)
- Pipe properties (pipes_x, pipes_y, pipes_w, pipes_h)
- Oscillation settings (Pipe_Osc_Amp, Pipe_Osc_Freq)
- Sound icon dimensions (sound_x, sound_y)
- Opening Space between pipes (Opening_Space)

---

### 4. **assets.py** - Resource Loader

**Purpose**: Load all game images and sounds with proper path resolution.

**Loaded Assets**:

| Type | File | Usage |
|------|------|-------|
| **Images** | | |
| Background | IMAGES/flappybirdbg.png | Scrolling background |
| Ground | IMAGES/ground.png | Bottom scrolling platform |
| Bird Frame 1 | IMAGES/bird1.png | Bird resting pose |
| Bird Frame 2 | IMAGES/bird2.png | Bird flapping pose |
| Top Pipe | IMAGES/top.png | Overhead obstacle |
| Bottom Pipe | IMAGES/bottom.png | Ground-level obstacle |
| Sound On | IMAGES/sounds_on.png | UI indicator |
| Sound Off | IMAGES/sounds_off.png | UI indicator |
| **Sounds** | | |
| Flap | SFX/sfx_wing.wav | Jump sound effect |
| Point | SFX/sfx_point.wav | Score increment |
| Hit | SFX/sfx_hit.wav | Collision sound |
| Swoosh | SFX/sfx_swooshing.wav | Menu transition |
| Die | SFX/sfx_die.wav | Game over sound |
| **Music** | SFX/background_music.ogg | Looping background track |

**Path Resolution**:
```python
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Resolves from CODES/ → RUSSELBIRD(2)/ for asset access
```

---

### 5. **bird.py** - Bird Class & Animation

**Purpose**: Manage bird sprite, animation, and rotation.

**Bird Class** (inherits from pygame.Rect):

```python
class Bird(pygame.Rect):
    Attributes:
    - bird_images: Dictionary with bird1 and bird2 sprites
    - is_flapping: Boolean flag for animation state
    - flap_timer: Counter for flap animation duration (8 frames)
    - current_img: Currently displayed sprite
    - angle: Rotation angle (-25 to 25 degrees)
    - velocity_y: Current vertical velocity
    
    Methods:
    - start_flap(): Trigger flapping animation
    - update_animation(): Update animation frame
    - update_rotation(velocity_y): Rotate based on velocity
    - get_rotated_image(): Return rotated sprite
```

**Animation Logic**:
- **Idle State**: Shows bird1, angle=0°
- **Jumping**: Shows bird2 (wings up), angle=25° (nose up)
- **Falling**: Shows bird1, angle=-25° (nose down)

**Visual Feedback**:
- Nose points UP when ascending (velocity < -5)
- Nose points DOWN when descending (velocity > 5)
- Horizontal when stable (-5 ≤ velocity ≤ 5)

---

### 6. **pipes.py** - Pipe Class

**Purpose**: Define pipe obstacles.

**Pipe Class** (inherits from pygame.Rect):

```python
class Pipe(pygame.Rect):
    Attributes:
    - img: Pipe sprite image
    - passed: Boolean (has bird passed safely?)
    - base_y: Initial Y position
    - spawn_time: When pipe was created (for oscillation)
    - phase_offset: Unique oscillation offset per pair
    
    Used for:
    - Collision detection via pygame.Rect
    - Tracking if score should increment
    - Calculating oscillation position
```

**Why Phase Offset?**
Different pipe pairs start oscillating at different phases of the sine wave, creating varied obstacle patterns.

---

### 7. **game_functions.py** - Core Game Mechanics

**Purpose**: Implement all drawing, physics, and collision logic.

**Key Functions**:

#### `move(bird, pipes, sounds, game_state)`
**Handles**: Physics, collision detection, scoring, difficulty updates.

**Physics Calculations**:
```python
# Gravity effect
velocity_y += gravity

# Bird movement
bird.y += velocity_y

# Boundary checking
if bird.y >= ground_y or bird.y <= 0:
    game_over = True
```

**Pipe Oscillation** (when score ≥ 10):
```python
offset = sin(elapsed * frequency + phase) * amplitude
pipe.y = pipe.base_y + offset
```

**Collision Detection**:
- Bird vs Ground/Sky
- Bird vs Top Pipe
- Bird vs Bottom Pipe

**Scoring**:
- +1 point when bird passes through pipe center
- Marked via `pipe.passed` flag to prevent double-scoring

#### `draw(window, bird, pipes, assets, score, high_score, game_over, ...)`
**Renders**: All game elements in proper order.

```
1. Background (scrolls at 60% speed)
2. Pipes (static or oscillating)
3. Bird (with rotation)
4. Ground (scrolling)
5. Score display (top center)
6. Game Over screen (if active)
```

#### `update_difficulty(score)`
Returns appropriate difficulty settings based on current score.

---

### 8. **main_menu.py** - Main Menu Interface

**Purpose**: Create the game start screen with animations.

**Features**:
- **Animated Background**: Scrolling parallax background
- **Bouncing Bird**: Sinusoidal vertical animation
- **Interactive Buttons**:
  - PLAY - Start game
  - HELP - View instructions
  - QUIT - Exit application
- **Music Toggle**: M key toggles background music

**Animation Details**:
```python
# Background scrolling
bg_x1, bg_x2 -= bg_speed (1 pixel/frame)

# Bird bouncing
bird_bounce_offset = sin(time * 0.01) * 5  # ±5 pixel range

# Bird frame animation
frame toggles between bird1 and bird2 every 15 frames
```

**Button Interaction**:
- Hover highlights button
- Click detection via mouse position
- Returns action string to main program

---

### 9. **pause_menu.py** - Pause Menu

**Purpose**: Display pause screen when P or ESC pressed during gameplay.

**Features**:
- Semi-transparent dark overlay (128 alpha)
- Game snapshot shown in background
- Resume / Exit to Menu buttons
- Keyboard support (P/ESC to resume)

**Visual Design**:
- Buttons highlight on hover
- Shadow text for readability
- 50px title font, 30px button font

---

### 10. **help.py** - Help Screen

**Purpose**: Display game controls and instructions.

**Contents Displayed**:
```
HOW TO PLAY
CONTROLS:
SPACE / W / UP - Jump
P / ESC - Pause Game
M - Toggle Music
Q - Quit to Menu
```

**Visual Elements**:
- Same scrolling background as menu
- Bouncing bird animation
- Beige instruction board
- Back button (B key or click)

---

### 11. **transition.py** - Fade Effects

**Purpose**: Create visual transitions between screens.

**Fade Effect Logic**:
```
Fade OUT (0→255 alpha):
- Gradually darken screen
- 30 steps over ~200ms

Fade IN (255→0 alpha):
- Gradually lighten screen
- 30 steps over ~200ms
```

Used for:
- Menu → Game transitions
- Game Over → Menu
- Help → Menu

---

## Game Physics & Mechanics

### Bird Movement
```
Input: Player presses SPACE/W/UP
Effect: velocity_y = jump_strength (-6)
Result: Bird rises with decreasing speed due to gravity

Frame Update:
velocity_y += gravity (0.4)  # Increases each frame
bird.y += velocity_y         # Move bird

Terminal velocity reached when gravity > upward velocity
```

### Pipe System
```
Pipe Creation: Every 2000ms (2 seconds)
Spawned Position: Right edge of screen (x = 360)
Vertical Position: Random with constraints

Gap Calculation:
- Opening space between pipes: ~123 pixels
- Random offset: ±(PIPE_HEIGHT/4) = ±128 pixels
- Ensures playable but challenging gaps

Oscillation (Score ≥ 10):
offset = sin(elapsed_time * frequency + phase) * amplitude
new_y = base_y + offset

Movement:
Each frame: pipe.x += velocity_x (increasingly negative)
Removed when x < -pipe_width (-64)
```

### Collision Detection
```
Ground Collision:
if bird.y >= (Game_Height - 62.5 - bird_height):
    game_over = True

Ceiling Collision:
if bird.y <= 0:
    game_over = True

Pipe Collision:
if bird.colliderect(top_pipe) or bird.colliderect(bottom_pipe):
    game_over = True

All collisions trigger:
- Hit SFX + Die SFX
- High score update (if score > previous best)
- Game over state
```

### Scoring System
```
Trigger: Bird moves past pipe center (bird.x > pipe.x + pipe_width)
Condition: Pipe not yet marked as passed
Action: 
  - Increment score by 1
  - Play point SFX
  - Mark pipe as passed (prevent double scoring)

Difficulty Update: Immediately check score tier and adjust physics
```

---

## Difficulty System

**Why Difficulty Matters**:
- Game gets progressively harder to stay challenging
- Encourages repeated play and score improvement
- Different mechanics activate at score milestones

**Tiers**:

| Score | Speed | Gravity | Jump | Oscillation | Amplitude |
|-------|-------|---------|------|-------------|-----------|
| 0-4 | -2.0 | 0.40 | -6.0 | 0.0020 | 30 |
| 5-9 | -2.8 | 0.42 | -6.3 | 0.0023 | 32 |
| 10-14 | -3.3 | 0.45 | -6.6 | 0.0026 | 34 |
| 15-19 | -3.8 | 0.48 | -6.9 | 0.0029 | 36 |
| 20+ | -4.3 | 0.50 | -7.2 | 0.0032 | 38 |

**Key Milestone: Score 10**
- Pipe oscillation BEGINS (pipes move up/down unpredictably)
- Pipes move 65% faster
- Gravity increases 12.5%

---

## Key Features

### 1. **Scrolling Parallax Background**
- Background moves at 60% of pipe speed (visual depth)
- Ground scrolls at same speed as pipes
- Continuous loop when texture exits screen

### 2. **Bird Animation**
- 2-frame animation (wings up/down)
- Changes based on flap action
- 8-frame flap duration

### 3. **Dynamic Rotation**
- Bird nose rotates based on vertical velocity
- +25° when jumping, -25° when falling
- Visual feedback of flight state

### 4. **Sound Design**
- Background music loops throughout
- 5 distinct sound effects (flap, point, hit, swoosh, die)
- Music toggle (M key)

### 5. **Progressive Difficulty**
- Automatic difficulty scaling
- Major change at score 10 (pipe oscillation)
- Smooth difficulty curve

### 6. **UI/UX Elements**
- Interactive menu buttons with hover states
- Pause functionality mid-game
- Help/Instructions screen
- Game Over scoreboard

### 7. **High Score Tracking**
- Best score persists during session
- Shows on game over screen
- Encourages competitive replaying

---

## How to Run

### Prerequisites
```bash
pip install pygame-ce
```

### Running the Game
```powershell
cd "c:\Users\preci\OneDrive\RUSSELBIRD(2) 2\RUSSELBIRD(2)"
python CODES/main.py
```

### Keyboard Controls
| Key | Action |
|-----|--------|
| SPACE / W / UP | Jump |
| P / ESC | Pause/Resume |
| M | Toggle Music |
| Q | Quit to Menu (on Game Over) |
| B / ESC | Back (from Help) |
| Mouse | Click menu buttons |

### Game Over Recovery
- Press SPACE to restart
- Press Q to return to menu

---

## Code Execution Flow (Detailed)

```
1. Program Start
   ├─ import pygame and modules
   ├─ os.chdir() to parent directory
   ├─ pygame.init() and pygame.mixer.init()
   ├─ Create 360x640 window
   └─ Load all assets

2. Main Menu Loop
   ├─ Render scrolling background
   ├─ Draw bouncing bird
   ├─ Display title and buttons
   ├─ Check for button clicks
   └─ Return action (play/help/quit)

3. If PLAY selected
   ├─ Create Bird instance
   ├─ Initialize game variables
   ├─ Create pipe timer (2000ms)
   └─ Enter game loop (60 FPS)

4. Game Loop (per frame, 16.67ms)
   ├─ Handle Events
   │  ├─ Check for pipe creation (every 2s)
   │  ├─ Check for jump input
   │  ├─ Check for pause input
   │  ├─ Check for music toggle
   │  └─ Check for quit
   │
   ├─ Update Game State
   │  ├─ Apply gravity: velocity_y += gravity
   │  ├─ Update bird position: bird.y += velocity_y
   │  ├─ Move pipes: pipe.x += velocity_x
   │  ├─ Update pipe oscillation (if score ≥ 10)
   │  └─ Check difficulty tier
   │
   ├─ Collision Detection
   │  ├─ Check ground collision
   │  ├─ Check ceiling collision
   │  ├─ Check pipe collisions
   │  └─ If collision: game_over = True
   │
   ├─ Scoring
   │  ├─ Check if bird passed pipe
   │  └─ If yes: score += 1
   │
   ├─ Rendering
   │  ├─ Draw background (parallax)
   │  ├─ Draw pipes
   │  ├─ Draw bird (with rotation)
   │  ├─ Draw ground
   │  ├─ Draw score
   │  └─ If game_over: draw game over screen
   │
   ├─ Display Update
   │  └─ pygame.display.update()
   │
   └─ Frame Rate Cap
      └─ clock.tick(60)

5. Game Over State
   ├─ Display scoreboard
   ├─ Show current score and best score
   ├─ Prompt for restart (SPACE) or quit (Q)
   └─ Return to menu or restart

6. Return to Menu
   └─ Loop back to step 2
```

---

## Architecture Summary

```
┌──────────────────────────────────────────────────────┐
│              GAME APPLICATION (main.py)             │
├──────────────────────────────────────────────────────┤
│                                                      │
│  ┌───────────────┐  ┌──────────────┐  ┌──────────┐ │
│  │  main_menu.py │  │   help.py    │  │pause_menu│ │
│  │  (UI Layer)   │  │  (UI Layer)  │  │ (UI)     │ │
│  └───────┬───────┘  └──────┬───────┘  └────┬─────┘ │
│          │                 │               │        │
│  ┌───────▼─────────────────▼───────────────▼──────┐ │
│  │         game_functions.py                      │ │
│  │  (Physics, Collision, Rendering)              │ │
│  └────┬──────────────┬──────────────┬────────┬───┘ │
│       │              │              │        │     │
│  ┌────▼──┐  ┌───────▼───┐  ┌──────▼──┐  ┌─▼────┐ │
│  │bird.py│  │ pipes.py  │  │assets.py│  │trans-│ │
│  │(Logic)│  │ (Logic)   │  │(Loader) │  │ition │ │
│  └───────┘  └───────────┘  └────┬────┘  │(VFX) │ │
│                                  │       └──────┘ │
│  ┌──────────────────────────────▼─────────────┐  │
│  │  config.py / constants.py                  │  │
│  │  (Configuration & Static Values)           │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
└──────────────────────────────────────────────────────┘
         ▲                                    ▲
         │                                    │
    ┌────┴────────────────┬───────────────────┴──┐
    │                     │                      │
 pygame                 Assets              Resources
 (Framework)        (Images, Sounds)      (FONT, SFX)
```

---

## Performance Notes

**Frame Rate**: 60 FPS target
- Each frame: ~16.67 milliseconds
- Game loop optimized for consistency

**Memory Usage**:
- Assets loaded once at startup
- No memory leaks in loops
- Pipes cleaned up when off-screen

**Physics Calculation**:
- Simple gravity-based movement
- Sine function for oscillation (O(1) lookup)
- Collision detection uses pygame.Rect (optimized)

---

## Conclusion

**Russel in the Wonderland** is a well-architected game demonstrating:
- ✅ Clean separation of concerns (UI, physics, rendering)
- ✅ Progressive difficulty system
- ✅ Responsive controls and smooth animations
- ✅ Professional UI/UX with transitions
- ✅ Sound and visual feedback
- ✅ Scalable design for future enhancements

The modular structure makes it easy to add features like:
- Multiple difficulty modes
- Leaderboards with high score persistence
- Power-ups and special items
- Different bird skins
- Additional levels/themes

---

**Created**: November 16, 2025  
**Framework**: Pygame-CE 2.5.6  
**Python Version**: 3.14.0+  
**Game Type**: Endless Runner / Arcade  
**Target Audience**: Casual Players  
