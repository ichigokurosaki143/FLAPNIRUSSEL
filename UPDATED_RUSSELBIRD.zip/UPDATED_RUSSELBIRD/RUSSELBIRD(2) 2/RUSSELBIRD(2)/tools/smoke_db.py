import os, tempfile, sys
# create temp db
tmp = tempfile.NamedTemporaryFile(prefix='smoke_test_', suffix='.db', delete=False)
path = tmp.name
tmp.close()
print('tmp db path =', path)
os.environ['FLAPPY_DB'] = path
# ensure CODES dir on sys.path
here = os.path.dirname(os.path.abspath(__file__))
repo_root = os.path.dirname(here)
codes_path = os.path.join(repo_root, 'CODES')
if codes_path not in sys.path:
    sys.path.insert(0, codes_path)
import database
print('DB_NAME in module:', database.DB_NAME)
# init
database.init_db()
print('init_db done')
ok = database.add_user('smoketest', 'hash')
print('add_user returned', ok)
print('authenticate:', database.authenticate_user('smoketest'))
print('add_score returned', database.add_score('smoketest', 10, 'classic'))
print('get_leaderboard:', database.get_leaderboard(5,'classic'))
print('add_achievement returned', database.add_achievement('smoketest','ach1'))
print('get_achievements:', database.get_achievements('smoketest'))
# cleanup
try:
    os.remove(path)
except:
    pass
print('done')
