import sys, os
# Make sure package directory is discoverable from repo root
repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
codes_dir = os.path.join(repo_root, 'CODES')
print('repo_root=', repo_root)
print('codes_dir=', codes_dir)
# Insert codes_dir so local imports work
sys.path.insert(0, codes_dir)

print('Trying package import: from CODES import database')
try:
    from CODES import database
    print('OK: package import worked')
except Exception as e:
    print('Package import failed:', e)

print('Trying local import: import database')
try:
    import database
    print('OK: local import worked')
except Exception as e:
    print('Local import failed:', e)

print('Try importing UI modules via package: leaderboard, main_menu, auth')
try:
    from CODES import leaderboard, main_menu, auth
    print('OK: imported leaderboard, main_menu, auth via package')
except Exception as e:
    print('Package import for UI modules failed:', e)

print('Done import checks')
