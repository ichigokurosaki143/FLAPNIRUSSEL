# main_menu.py
import pygame
import math
from constants import *
import session

# === MAKE ANIMATION VARIABLES GLOBAL TO THE MODULE ===
bg_x1 = 0
bg_x2 = Game_Width
bird_frame = 0
bird_animation_timer = 0
bird_bounce_offset = 0

def main_menu (window, assets, clock):
    global bg_x1, bg_x2, bird_frame, bird_animation_timer, bird_bounce_offset
    
    font = pygame.font.Font ("FONT/flappy-font.ttf", 44)
    small_font = pygame.font.Font ("FONT/flappy-font.ttf", 28)
    slight_small = pygame.font.Font ("FONT/flappy-font.ttf", 20)
    tiny_font = pygame.font.Font ("FONT/flappy-font.ttf", 18)
    super_small = pygame.font.Font ("FONT/flappy-font.ttf", 10)

    def draw_text (text, font, color, shadow, surface, x, y):
        shadow_obj = font.render (text, True, shadow)
        shadow_rect = shadow_obj.get_rect (center = (x + 2, y + 2))
        surface.blit (shadow_obj, shadow_rect)
        
        text_obj = font.render (text, True, color)
        text_rect = text_obj.get_rect (center=(x, y))
        surface.blit (text_obj, text_rect)

    # === CONSTANTS ONLY ===
    bg_speed = 1
    bird_animation_speed = 15
    bird_bounce_speed = 0.01  
    bird_bounce_range = 5

    while True:
        click = False
        music_toggled = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    music_toggled = True

        # === UPDATE ANIMATION (USING GLOBAL VARIABLES) ===
        bg_x1 -= bg_speed
        bg_x2 -= bg_speed
        
        if bg_x1 <= -Game_Width:
            bg_x1 = bg_x2 + Game_Width
        if bg_x2 <= -Game_Width:
            bg_x2 = bg_x1 + Game_Width

        bird_animation_timer += 1
        if bird_animation_timer >= bird_animation_speed:
            bird_animation_timer = 0
            bird_frame = (bird_frame + 1) % 2
        
        bird_bounce_offset = math.sin (pygame.time.get_ticks() * bird_bounce_speed) * bird_bounce_range

        # --- DRAW EVERYTHING ---
        window.blit(assets["bg"], (bg_x1, 0))
        window.blit(assets["bg"], (bg_x2, 0))

        current_bird_img = assets["bird1"] if bird_frame == 0 else assets["bird2"]
        bird_rect = current_bird_img.get_rect(center=(bird_x, bird_y + bird_bounce_offset))
        window.blit(current_bird_img, bird_rect)

        draw_text("Russel In", font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 100)
        draw_text("The Wonderland", font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 150)

        mx, my = pygame.mouse.get_pos()
        margin = 10
        achievements = 50
        logout = 10
        button_size = 28
        ach_button = 48

        help_rect = pygame.Rect(Game_Width - button_size - margin, margin,
                        button_size, button_size)
        play_rect = pygame.Rect (Game_Width //2 - 75, Game_Height//2 + 50, 150, 50)
        quit_rect = pygame.Rect (Game_Width //2 - 75, Game_Height//2 + 120, 150, 50)
        leaderboard_rect = pygame.Rect (Game_Width //2 - 75, Game_Height//2 + 190, 150, 50)
        awards_rect = pygame.Rect (achievements, margin, ach_button, button_size)
        # Place LOGIN directly above the PLAY button (stacked)
        login_rect = pygame.Rect(play_rect.x, play_rect.y - 60, play_rect.width, 40)
        # Logout button in top-right
        logout_rect = pygame.Rect(logout, margin, button_size, button_size)

        # Play button
        if play_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (100, 200, 100), play_rect, border_radius = 10)
            pygame.draw.rect (window, (50, 150, 50), play_rect, 3, border_radius = 10)

            if click:
                # Check if user is logged in
                current_user = session.get_user()
                if current_user:
                    return "play"
                else:
                # Not logged in, go to auth menu
                    from auth import auth_menu
                    auth_menu(window, assets, clock)

        else:
            pygame.draw.rect (window, (80, 180, 80), play_rect, border_radius = 10)
            pygame.draw.rect (window, (50, 150, 50), play_rect, 3, border_radius = 10)
        
        draw_text ("PLAY", small_font, (255, 255, 255), (0, 0, 0), window, play_rect.centerx, play_rect.centery)

        # Login button
        if login_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 120, 200), login_rect, border_radius=8)
            pygame.draw.rect(window, (60, 80, 160), login_rect, 3, border_radius=8)
            if click:
                from auth import auth_menu
                auth_menu(window, assets, clock)
        else:
            pygame.draw.rect(window, (60, 80, 160), login_rect, border_radius=8)
            pygame.draw.rect(window, (40, 60, 120), login_rect, 3, border_radius=8)
        draw_text ("LOGIN", small_font, (255, 255, 255), (0, 0, 0), window, login_rect.centerx, login_rect.centery)

        # Quit button
        if quit_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (200, 100, 100), quit_rect, border_radius = 10)
            pygame.draw.rect (window, (150, 50, 50), quit_rect, 3, border_radius = 10)
            if click:
                return "quit"
        
        else:
            pygame.draw.rect (window, (180, 80, 80), quit_rect, border_radius = 10)
            pygame.draw.rect (window, (150, 50, 50), quit_rect, 3, border_radius = 10)
        
        draw_text ("QUIT", small_font, (255, 255, 255), (0, 0, 0), window, quit_rect.centerx, quit_rect.centery)

        #help button
        if help_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (0, 180, 216), help_rect, border_radius = 10)
            pygame.draw.rect (window, (65, 105, 225), help_rect, 3, border_radius = 10)
            if click:
                return "help"
            
        else:
            pygame.draw.rect (window, (0, 119, 182), help_rect, border_radius = 10)
            pygame.draw.rect (window, (65, 105, 225), help_rect, 3, border_radius = 10)
        
        draw_text ("?", tiny_font, (255, 255, 255), (0, 0, 0), window, help_rect.centerx, help_rect.centery)
        
        # Leaderboard button
        if leaderboard_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (200, 150, 100), leaderboard_rect, border_radius = 10)
            pygame.draw.rect (window, (150, 100, 50), leaderboard_rect, 3, border_radius = 10)
            if click:
                return "leaderboard"
            
        else:
            pygame.draw.rect (window, (180, 130, 80), leaderboard_rect, border_radius = 10)
            pygame.draw.rect (window, (150, 100, 50), leaderboard_rect, 3, border_radius = 10)
        
        draw_text ("LEADERBOARDS", slight_small, (255, 255, 255), (0, 0, 0), window, leaderboard_rect.centerx, leaderboard_rect.centery)

        # Achievements button (separate from Scores)
        if awards_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (120, 160, 200), awards_rect, border_radius=10)
            pygame.draw.rect(window, (80, 120, 160), awards_rect, 3, border_radius=10)
            if click:
                return "awards"
        else:
            pygame.draw.rect(window, (100, 140, 180), awards_rect, border_radius=10)
            pygame.draw.rect(window, (80, 120, 160), awards_rect, 3, border_radius=10)
        draw_text ("awards", super_small, (255, 255, 255), (0, 0, 0), window, awards_rect.centerx, awards_rect.centery)

        # Logout button top-right (clears session and stays on menu)
        if logout_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (160,80,60), logout_rect, border_radius=10)
            pygame.draw.rect(window, (120,60,40), logout_rect, 2, border_radius=10)
            if click:
                session.logout()
        else:
            pygame.draw.rect(window, (140,70,50), logout_rect, border_radius=10)
            pygame.draw.rect(window, (100,50,30), logout_rect, 2, border_radius=10)
        draw_text ("OUT", super_small, (255,255,255), (0,0,0), window, logout_rect.centerx, logout_rect.centery)

        pygame.display.update ()
        clock.tick (60)

        # RETURN AFTER FRAME COMPLETE
        if music_toggled:
            return "toggle_music"