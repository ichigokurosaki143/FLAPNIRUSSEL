import pygame
from constants import *

def fade_effect (window, duration = 200):
    
    # Simple Fade In/Out Transition
    fade = pygame.Surface ((Game_Width, Game_Height))

    # Fade out
    for alpha in range (0, 255, 5):
        fade.fill ((0, 0, 0))
        fade.set_alpha(alpha)
        window.blit(fade, (0, 0))
        pygame.display.update ()
        pygame.time.delay (duration // 30)

        # Fade in
    for alpha in range (255, -1, -5):
        fade.fill ((0, 0, 0))
        fade.set_alpha(alpha)
        window.blit(fade, (0, 0))
        pygame.display.update ()
        pygame.time.delay (duration // 30)