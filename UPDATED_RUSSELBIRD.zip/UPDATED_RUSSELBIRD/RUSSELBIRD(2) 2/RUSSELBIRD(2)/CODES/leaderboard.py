# leaderboard.py
import pygame
from constants import Game_Width, Game_Height
import session

# Robust import: prefer package import when available, fallback to local module
try:
    from CODES import database
except Exception:
    import database

# sub tab = classic and adv tab

def show_leaderboard(window, clock, start_mode: str = 'leaderboard'):
    """
    Display the leaderboard panel with top Classic mode scores
    """
    
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 40)
    font_rank = pygame.font.Font("FONT/flappy-font.ttf", 24)
    font_score = pygame.font.Font("FONT/flappy-font.ttf", 22)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 18)
    font_small_2 = pygame.font.Font("FONT/flappy-font.ttf", 14)
    last_small = pygame.font.Font("FONT/flappy-font.ttf", 12)
    
    # UI mode: either showing leaderboards or achievements panel
    ui_mode = start_mode  # 'leaderboard' or 'achievements'
    # Sub-page/tab for the selected mode
    sub_page = 'classic'  # 'classic' or 'adventure'
    scroll = {"classic": 0}

    # Panel dimensions with proper padding
    panel_x = 20
    panel_w = Game_Width - 40
    panel_y = 100
    panel_h = Game_Height - panel_y - 60
    panel_rect = pygame.Rect(panel_x, panel_y, panel_w, panel_h)

    # Define main mode buttons (Leaderboards / Achievements)
    tab_h = 40
    tab_padding = 12
    tab_y = 20  # Position for main mode tabs
    margin = 20
    available_w = Game_Width - 2 * margin
    tab_w = max(80, min(220, (available_w - 2 * tab_padding) // 3))
    total_tabs_w = 2 * tab_w + tab_padding  # Only 2 main tabs now
    start_x = margin + max(0, (available_w - total_tabs_w) // 2)
    total_sub_w = 2 * tab_w + tab_padding  # 2 sub-tabs
    sub_start = margin + max(0, (available_w - total_sub_w) // 2)
    ldr = pygame.Rect(sub_start, tab_y, tab_w, tab_h)
    ach = pygame.Rect(sub_start + tab_w + tab_padding, tab_y, tab_w, tab_h)
    
    # Main mode buttons
    btn_leaderboards = pygame.Rect(start_x, tab_y, tab_w, tab_h)
    btn_achievements = pygame.Rect(start_x + tab_w + tab_padding, tab_y, tab_w, tab_h)

    def draw_text (text, font, color, shadow, surface, x, y):
        shadow_obj = font.render (text, True, shadow)
        shadow_rect = shadow_obj.get_rect (center = (x + 2, y + 2))
        surface.blit (shadow_obj, shadow_rect)
        
        text_obj = font.render (text, True, color)
        text_rect = text_obj.get_rect (center=(x, y))
        surface.blit (text_obj, text_rect)

    def truncate_text(font, text, max_width):
        """Return a possibly-truncated text that fits within max_width (pixels)."""
        if text is None:
            return ''
        text = str(text)
        if max_width <= 0:
            return ''
        ell = '...'
        ell_w = font.size(ell)[0]
        if ell_w > max_width:
            return ''
        if font.size(text)[0] <= max_width:
            return text
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi) // 2
            candidate = text[:mid].rstrip() + ell
            if font.size(candidate)[0] <= max_width:
                lo = mid + 1
            else:
                hi = mid
        res = text[:max(0, lo-1)].rstrip() + ell
        return res

    def render_panel_rows(rows, x, w, y0, h, page_key):
        row_h = 44
        total = len(rows)
        max_scroll = max(0, total * row_h - h)
        s = scroll.get(page_key, 0)
        s = min(s, max_scroll)
        scroll[page_key] = s
        mouse_x, mouse_y = pygame.mouse.get_pos()
        tooltip = None
        
        # Calculate content area that aligns with panel borders
        content_x = x + 2  # Align with inner panel border
        content_width = w - 4  # Match panel inner width
        content_y = y0 + 2  # Align with inner panel border
        content_height = h - 4  # Match panel inner height
        
        # Draw table header that aligns with panel
        header_y = content_y
        header_height = 35
        header_rect = pygame.Rect(content_x, header_y, content_width, header_height)
        pygame.draw.rect(window, (30, 45, 70), header_rect)
        pygame.draw.rect(window, (100, 150, 200), header_rect, 1)
        
        # Header text - properly aligned
        rank_header = font_small.render("RANK", True, (255, 255, 255))
        name_header = font_small.render("PLAYER", True, (255, 255, 255))
        score_header = font_small.render("SCORE", True, (255, 255, 255))
        
        # Align header text with row content
        window.blit(rank_header, (content_x + 15, header_y + 10))
        window.blit(name_header, (content_x + 80, header_y + 10))
        window.blit(score_header, (content_x + content_width - 70, header_y + 10))
        
        # Content area starts below header
        table_content_y = header_y + header_height + 2
        table_content_height = content_height - header_height - 2
        
        for idx, r in enumerate(rows):
            if not (isinstance(r, (list, tuple)) and len(r) >= 2):
                continue
            uname = r[0]
            sc = r[1]
            
            # Calculate row position - aligned with content area
            yy = table_content_y + idx * row_h - s
            
            # Skip if row is outside visible area
            if yy + row_h < table_content_y or yy > table_content_y + table_content_height:
                continue
            
            # Row background - perfectly aligned with panel borders
            row_rect = pygame.Rect(content_x, yy, content_width, row_h - 4)
            rc = (40, 60, 90) if idx % 2 == 0 else (50, 70, 100)
            pygame.draw.rect(window, rc, row_rect)
            pygame.draw.rect(window, (100, 150, 200), row_rect, 1)
            
            # Rank, name, score - aligned with header and panel borders
            rank_txt = font_rank.render(f"#{idx+1}", True, (255, 215, 0) if idx < 3 else (255,255,255))
            window.blit(rank_txt, (content_x + 15, yy + 10))
            
            # Name column - aligned with header
            name_max = content_width - 160  # Account for rank and score areas
            disp = truncate_text(font_rank, uname, name_max)
            name_txt = font_rank.render(disp, True, (255,255,255))
            name_rect = name_txt.get_rect(topleft=(content_x + 80, yy + 10))
            window.blit(name_txt, name_rect)
            
            # Score column - aligned with header
            score_txt = font_score.render(str(sc), True, (255,255,255))
            score_rect = score_txt.get_rect(topright=(content_x + content_width - 15, yy + 10))
            window.blit(score_txt, score_rect)
            
            if name_rect.collidepoint((mouse_x, mouse_y)):
                tooltip = uname
                
        return tooltip

    def render_achievements_rows(achievements, x, w, y0, h):
        """Render achievements in a table format with columns"""
        row_h = 35
        content_x = x + 2
        content_width = w - 4
        content_y = y0 + 2
        content_height = h - 4
        
        # Draw achievements header
        header_y = content_y
        header_height = 35
        header_rect = pygame.Rect(content_x, header_y, content_width, header_height)
        pygame.draw.rect(window, (30, 45, 70), header_rect)
        pygame.draw.rect(window, (100, 150, 200), header_rect, 1)
        
        # Header text for achievements
        achievement_header = font_small.render("ACHIEVEMENT", True, (255, 255, 255))
        date_header = font_small.render("DATE EARNED", True, (255, 255, 255))
        mode_header = font_small.render("MODE", True, (255, 255, 255))
        
        # Align header text
        window.blit(achievement_header, (content_x + 20, header_y + 10))
        window.blit(date_header, (content_x + content_width - 200, header_y + 10))
        window.blit(mode_header, (content_x + content_width - 80, header_y + 10))
        
        # Content area starts below header
        table_content_y = header_y + header_height + 2
        table_content_height = content_height - header_height - 2
        
        for idx, achievement in enumerate(achievements):
            # Handle different achievement data formats
            if isinstance(achievement, (list, tuple)):
                if len(achievement) >= 3:
                    # Format: [achievement_name, date_earned, game_mode]
                    achievement_name = achievement[0]
                    date_earned = achievement[1] if len(achievement) > 1 else "N/A"
                    game_mode = achievement[2] if len(achievement) > 2 else "N/A"
                elif len(achievement) >= 1:
                    # Format: [achievement_name] only
                    achievement_name = achievement[0]
                    date_earned = "N/A"
                    game_mode = "N/A"
                else:
                    continue
            else:
                # Single string format
                achievement_name = str(achievement)
                date_earned = "N/A"
                game_mode = "N/A"
            
            # Calculate row position
            yy = table_content_y + idx * row_h
            
            # Skip if row is outside visible area
            if yy + row_h < table_content_y or yy > table_content_y + table_content_height:
                continue
            
            # Row background
            row_rect = pygame.Rect(content_x, yy, content_width, row_h - 4)
            rc = (40, 60, 90) if idx % 2 == 0 else (50, 70, 100)
            pygame.draw.rect(window, rc, row_rect)
            pygame.draw.rect(window, (100, 150, 200), row_rect, 1)
            
            # Achievement name (truncated if too long)
            achievement_max_width = content_width - 250  # Space for date and mode
            disp_achievement = truncate_text(font_small, achievement_name, achievement_max_width)
            achievement_txt = font_small.render(disp_achievement, True, (255, 255, 255))
            window.blit(achievement_txt, (content_x + 20, yy + 8))
            
            # Date earned
            date_txt = font_small.render(str(date_earned), True, (200, 200, 200))
            window.blit(date_txt, (content_x + content_width - 200, yy + 8))
            
            # Game mode
            mode_txt = font_small.render(str(game_mode), True, (200, 200, 200))
            window.blit(mode_txt, (content_x + content_width - 80, yy + 8))
            
        return len(achievements)

    # main loop for pages
    running = True
    while running:
        # draw background gradient
        for y in range(Game_Height):
            t = y / Game_Height
            r = int(30 + (90 - 30) * t)
            b = int(50 + (140 - 50) * t)
            pygame.draw.line(window, (r, 0, b), (0, y), (Game_Width, y))

        # draw mode buttons (Leaderboards / Achievements)
        pygame.draw.rect(window, (80,150,200) if ui_mode == 'leaderboard' else (50,70,100), btn_leaderboards, border_radius=6)
        pygame.draw.rect(window, (90,150,200) if ui_mode == 'achievements' else (50,70,100), btn_achievements, border_radius=6)
        lb_label = font_small_2.render('LEADERBOARDS', True, (255,255,255))
        ach_label = font_small_2.render('ACHIEVEMENTS', True, (255,255,255))
        window.blit(lb_label, lb_label.get_rect(center=btn_leaderboards.center))
        window.blit(ach_label, ach_label.get_rect(center=btn_achievements.center))

        # panel frame with proper border
        pygame.draw.rect(window, (18,28,48), panel_rect)
        pygame.draw.rect(window, (100,150,200), panel_rect, 3)  # Thicker border

        # "CLASSIC" title
        draw_text("CLASSIC", font_title, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 80)

        # handle events
        events = pygame.event.get()
        for ev in events:
            if ev.type == pygame.QUIT:
                return 'quit'
            
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_ESCAPE):
                    return 'menu'
                if ev.key == pygame.K_RIGHT:
                    # next sub-page (classic <-> adventure)
                    sub_page = 'adventure' if sub_page == 'classic' else 'classic'
            
            if ev.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                # mode buttons
                if btn_leaderboards.collidepoint((mx, my)):
                    ui_mode = 'leaderboard'
                elif btn_achievements.collidepoint((mx, my)):
                    ui_mode = 'achievements'
                
                # mouse wheel events
                if ev.button == 4:  # wheel up
                    scroll[sub_page] = max(0, scroll.get(sub_page,0) - 44)
                if ev.button == 5:  # wheel down
                    scroll[sub_page] = scroll.get(sub_page,0) + 44
            
            if ev.type == pygame.MOUSEWHEEL:
                scroll[sub_page] = max(0, scroll.get(sub_page,0) - ev.y * 44)

        tooltip = None
        if ui_mode == 'leaderboard':
            # fetch fresh leaderboard for the active sub-page
            rows = database.get_leaderboard(limit=10, game_mode=sub_page)
            tooltip = render_panel_rows(rows, panel_x, panel_w, panel_y, panel_h, sub_page)
        else:
            # achievements panel: show logged-in user's achievements filtered by sub_page
            logged_user = session.get_user()
            # Align achievements area with panel borders
            achievement_x = panel_x + 2
            achievement_width = panel_w - 4
            achievement_y = panel_y + 2
            achievement_height = panel_h - 4
            
            if logged_user:
                achs = database.get_achievements(logged_user, game_mode=sub_page)
                if achs:
                    # Use the new column-based achievements renderer
                    achievement_count = render_achievements_rows(achs, panel_x, panel_w, panel_y, panel_h)
                    
                    # Show achievement count
                    count_text = font_small.render(f"Total Achievements: {achievement_count}", True, (200, 200, 100))
                    window.blit(count_text, (panel_x + 20, panel_y + panel_h - 25))
                else:
                    # No achievements message
                    no_achs_text = font_small.render("No achievements earned yet. Keep playing!", True, (180,180,200))
                    window.blit(no_achs_text, (panel_x + (panel_w - no_achs_text.get_width()) // 2, 
                                             panel_y + panel_h // 2 - 10))
            else:
                # Login hint with aligned background
                hint_area = pygame.Rect(achievement_x, achievement_y, achievement_width, achievement_height)
                pygame.draw.rect(window, (30, 45, 70), hint_area)
                pygame.draw.rect(window, (100, 150, 200), hint_area, 1)
                
                hint = font_small.render('Login to see your achievements', True, (180,180,200))
                window.blit(hint, (achievement_x + (achievement_width - hint.get_width()) // 2, 
                                 achievement_y + achievement_height // 2 - 10))

        # instructions
        instr = last_small.render('ESC to return to menu. Wheel to scroll.', True, (150,200,255))
        window.blit(instr, (Game_Width//2 - instr.get_width()//2, Game_Height - 25))

        # tooltip
        if tooltip:
            tip_s = font_small.render(tooltip, True, (255,255,255))
            mx, my = pygame.mouse.get_pos()
            pygame.draw.rect(window, (0,0,0), (mx+8, my+8, tip_s.get_width()+8, tip_s.get_height()+8))
            window.blit(tip_s, (mx+12, my+12))

        pygame.display.update()
        clock.tick(60)