# help.py

import pygame
import math
from constants import *
from main_menu import *



def help_menu (window, assets, clock):
    global bg_x1, bg_x2, bird_frame, bird_animation_timer, bird_bounce_offset

    font_title = pygame.font.Font ("FONT/flappy-font.ttf", 40)
    font_text = pygame.font.Font ("FONT/flappy-font.ttf", 24)
    font_small = pygame.font.Font ("FONT/flappy-font.ttf", 18)
    font_big = pygame.font.Font ("FONT/flappy-font.ttf", 45)

    def draw_text (text, font, color, shadow, surface, x, y):
        # Draw Shadow
        shadow_obj = font.render (text, True, shadow)
        shadow_rect = shadow_obj.get_rect (center = (x + 2, y + 2))    
        surface.blit (shadow_obj, shadow_rect)
        
        # Draw Text
        text_obj = font.render (text, True, color)
        text_rect = text_obj.get_rect (center = (x, y))    
        surface.blit (text_obj, text_rect)


    # == CONSTANTS ONLY ==
    bg_speed = 1
    bird_animation_speed = 15
    bird_bounce_speed = 0.01  
    bird_bounce_range = 5

    # Help screen loop
    while True:
        click = False

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_b, pygame.K_ESCAPE):
                    return "back"
                

        # === UPDATE ANIMATION (USING main_menu VARIABLES) ===
        bg_x1 -= bg_speed
        bg_x2 -= bg_speed
        
        if bg_x1 <= -Game_Width:
            bg_x1 = bg_x2 + Game_Width
        if bg_x2 <= -Game_Width:
            bg_x2 = bg_x1 + Game_Width

        bird_animation_timer += 1
        if bird_animation_timer >= bird_animation_speed:
            bird_animation_timer = 0
            bird_frame = (bird_frame + 1) % 2
        
        bird_bounce_offset = math.sin (pygame.time.get_ticks() * bird_bounce_speed) * bird_bounce_range


        # Draw 
        window.blit (assets ["bg"], (bg_x1, 0))        
        window.blit (assets ["bg"], (bg_x2, 0))


        # Draw game title
        draw_text ("Russel In", font_big, (255, 255, 255,), (155, 155, 155), window, Game_Width // 2, 100)
        draw_text ("The Wonderland", font_big, (255, 255, 255,), (155, 155, 155), window, Game_Width // 2, 150)


        current_bird_img = assets ["bird1"] if bird_frame == 0 else assets ["bird2"]
        bird_rect = current_bird_img.get_rect (center = (bird_x, bird_y + bird_bounce_offset))
        window.blit(current_bird_img, bird_rect)


        # Draw help board
        board_w, board_h = 320, 420
        board_x, board_y = (Game_Width - board_w) /2, (Game_Height - board_h) /2

        # Draw the help board
        pygame.draw.rect (window, (245, 222, 179), (board_x, board_y, board_w, board_h), border_radius = 15)
        pygame.draw.rect (window, (222, 184, 135), (board_x, board_y, board_w, board_h), 4, border_radius = 15)

        # Title
        draw_text ("HOW TO PLAY", font_title, (255, 255, 255), (155, 155, 155), window, Game_Width //2,  board_y + 40)


        # Content of Instructions
        instructions = [
            "CONTROLS:",
            "SPACE / W / UP - Jump",
            "P / ESC - Pause Game",
            "M - Toggle Music",
            "Q - Quit to Menu",
            ""
        ]

        # Draw Instructions
        y_pos = board_y + 80
        for line in instructions:

            if line and ":" in line:
                draw_text (line, font_text, (0, 0, 255), (155, 155, 155), window, Game_Width //2,  y_pos)
                y_pos += 30

            elif line:
                draw_text (line, font_text, (0, 0, 0), (155, 155, 155), window, Game_Width //2, y_pos)
                y_pos += 25

            else: # Empty Line
                y_pos += 10



        # Back Button
        back_rect = pygame.Rect (Game_Width // 2 - 75, board_y + board_h - 50, 150, 40)
        mx, my = pygame.mouse.get_pos ()

        if back_rect.collidepoint ((mx, my)):
            pygame.draw.rect (window, (100, 150, 200), back_rect, border_radius = 10)
            pygame.draw.rect (window, (50, 100, 150), back_rect, 3, border_radius = 10)

            if click:
                return "back"

        else:
            pygame.draw.rect (window, (80, 130, 180), back_rect, border_radius = 10)
            pygame.draw.rect (window, (50, 100, 150), back_rect, 3, border_radius = 10)

        draw_text ("(B)ACK", font_small, (255, 255, 255), (0, 0, 0), window, back_rect.centerx, back_rect.centery)

        pygame.display.update ()
        clock.tick (60)