# tower_victory.py
import pygame
import os
import math
from constants import Game_Width, Game_Height
from transition import fade_effect

class ParticleEffect:
    """Particle system for celebratory effects"""
    def __init__(self, x, y, vx, vy, life):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.max_life = life
        self.size = 5
    
    def update(self):
        self.x += self.vx
        self.vy += 0.2  # Gravity
        self.y += self.vy
        self.life -= 1
        self.size = int(5 * (self.life / self.max_life))
    
    def draw(self, surface):
        if self.life > 0:
            color = (255, 215, 0, int(255 * (self.life / self.max_life)))
            pygame.draw.circle(surface, (255, 215, 0), (int(self.x), int(self.y)), max(1, self.size))

def tower_victory_screen(window, clock, score):
    """
    Display interactive tower victory screen with animations and effects
    Returns: "continue" to keep playing, "menu" to return to menu
    """
    
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 50)
    font_text = pygame.font.Font("FONT/flappy-font.ttf", 30)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 16)

    
    # Load background tower image
    bg_img = None 
    try:
        bg_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "IMAGES/tower_bg.png")
        if os.path.exists(bg_path):
            bg_img = pygame.image.load(os.path.join("IMAGES/victorybg.png")).convert_alpha()
            bg_img = pygame.transform.scale(bg_img, (Game_Width, Game_Height))
    except:
        pass

    bird_img = None
    try:
        bird_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "IMAGES/bird1.png")
        if os.path.exists(bird_path):
            bird_img = pygame.image.load(os.path.join("IMAGES/bird1.png")).convert_alpha()
            bird_img = pygame.transform.scale(bird_img, (50, 50))
    except:
        pass
    
    # Animation state
    elapsed = 0
    particles = []
    continue_button_hover = False
    menu_button_hover = False
    continue_button_rect = None
    menu_button_rect = None
    
    # Victory screen loop
    while True:
        elapsed += 1
        click = False
        mouse_pos = pygame.mouse.get_pos()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True
                if continue_button_rect and continue_button_rect.collidepoint(mouse_pos):
                    return "continue"  # CONTINUE PLAYING
                if menu_button_rect and menu_button_rect.collidepoint(mouse_pos):
                    return "menu"  # RETURN TO MENU
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:  # Press C to continue
                    return "continue"
                if event.key == pygame.K_m:  # Press M for menu
                    return "menu"

        # Draw background
        if bg_img:
            window.blit(bg_img, (0, 0))
        else:
            # Fallback gradient effect if no background image
            for y in range(Game_Height):
                color_blend = int(135 + (106 - 135) * (y / Game_Height))
                pygame.draw.line(window, (color_blend, 206, 250), (0, y), (Game_Width, y))

        # Create celebratory particles
        if elapsed % 3 == 0 and elapsed < 120:
            for _ in range(3):
                import random
                vx = random.uniform(-3, 3)
                vy = random.uniform(-5, -1)
                particles.append(ParticleEffect(Game_Width // 2, 100, vx, vy, 60))

        # Update and draw particles
        for particle in particles[:]:
            particle.update()
            if particle.life <= 0:
                particles.remove(particle)
            else:
                particle.draw(window)

        if bird_img:
            bird_y = 80 + 80 * math.sin(elapsed * 0.05)
            bird_x = 70 + (elapsed * 1.5) % (Game_Width + 100)
            window.blit(bird_img, (bird_x, bird_y))

        # Draw congratulations message
        pulse = 1 + 0.1 * abs(math.sin(elapsed * 0.03))
        font_title_scaled = pygame.font.Font("FONT/flappy-font.ttf", int(40 * pulse))
        congratulations_text = font_title_scaled.render("CONGRATULATIONS!", True, (255, 215, 0))
        congratulations_shadow = font_title_scaled.render("CONGRATULATIONS!", True, (0, 0, 0))
        congratulations_rect = congratulations_text.get_rect(center=(Game_Width // 2, 50))
        congratulations_shadow_rect = congratulations_shadow.get_rect(center=(Game_Width // 2 + 2, 52))
        window.blit(congratulations_shadow, congratulations_shadow_rect)
        window.blit(congratulations_text, congratulations_rect)

        # Draw custom message
        message = "YOU PASSED THE TOWER!"
        message_text = font_text.render(message, True, (255, 255, 255))
        message_shadow = font_text.render(message, True, (0, 0, 0))
        message_rect = message_text.get_rect(center=(Game_Width // 2, Game_Height // 2 - 50))
        message_shadow_rect = message_shadow.get_rect(center=(Game_Width // 2 + 2, Game_Height // 2 - 48))
        window.blit(message_shadow, message_shadow_rect)
        window.blit(message_text, message_rect)

        # Draw score
        score_text = font_text.render(f"Current Score: {int(score)}", True, (255, 255, 200))
        score_shadow = font_text.render(f"Current Score: {int(score)}", True, (0, 0, 0))
        score_rect = score_text.get_rect(center=(Game_Width // 2, Game_Height // 2))
        score_shadow_rect = score_shadow.get_rect(center=(Game_Width // 2 + 2, Game_Height // 2 + 2))
        window.blit(score_shadow, score_shadow_rect)
        window.blit(score_text, score_rect)

        # ✅ DAGDAGAN NG 2 BUTTONS: CONTINUE AT MENU

        # Continue Button (Green)
        continue_button_width = 150
        continue_button_height = 50
        continue_button_x = Game_Width // 2 - continue_button_width - 10
        continue_button_y = Game_Height - 120
        continue_button_rect = pygame.Rect(continue_button_x, continue_button_y, continue_button_width, continue_button_height)

        if continue_button_rect.collidepoint(mouse_pos):
            continue_button_hover = True
            continue_button_color = (100, 200, 100)
        else:
            continue_button_hover = False
            continue_button_color = (80, 180, 80)

        pygame.draw.rect(window, continue_button_color, continue_button_rect, border_radius=10)
        pygame.draw.rect(window, (255, 255, 255), continue_button_rect, 3, border_radius=10)

        continue_text = font_small.render("CONTINUE PLAYING", True, (255, 255, 255))
        continue_text_rect = continue_text.get_rect(center=continue_button_rect.center)
        window.blit(continue_text, continue_text_rect)

        # Menu Button (Blue)
        menu_button_width = 150
        menu_button_height = 50
        menu_button_x = Game_Width // 2 + 10
        menu_button_y = Game_Height - 120
        menu_button_rect = pygame.Rect(menu_button_x, menu_button_y, menu_button_width, menu_button_height)

        if menu_button_rect.collidepoint(mouse_pos):
            menu_button_hover = True
            menu_button_color = (100, 150, 200)
        else:
            menu_button_hover = False
            menu_button_color = (80, 130, 180)

        pygame.draw.rect(window, menu_button_color, menu_button_rect, border_radius=10)
        pygame.draw.rect(window, (255, 255, 255), menu_button_rect, 3, border_radius=10)

        menu_text = font_small.render("BACK TO MENU", True, (255, 255, 255))
        menu_text_rect = menu_text.get_rect(center=menu_button_rect.center)
        window.blit(menu_text, menu_text_rect)

        # Draw keyboard hints
        hint_text = font_small.render("Press C to Continue  |  Press M for Menu", True, (255, 255, 255))
        hint_rect = hint_text.get_rect(center=(Game_Width // 2, Game_Height - 50))
        window.blit(hint_text, hint_rect)

        pygame.display.update()
        clock.tick(60)
