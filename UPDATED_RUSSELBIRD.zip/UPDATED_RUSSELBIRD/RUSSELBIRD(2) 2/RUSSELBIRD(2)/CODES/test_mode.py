import sys
sys.path.insert(0, '.')

from config import GameConfig

# Test Classic mode
print("=== TESTING CLASSIC MODE ===")
for score in [0, 5, 10, 15, 20]:
    settings = GameConfig.get_difficulty_settings(score, "classic")
    print(f"Score {score}: velocity_x={settings['velocity_x']}, gravity={settings['gravity']}")

print("\n=== TESTING ADVENTURE MODE ===")
for score in [0, 5, 10, 15, 20]:
    settings = GameConfig.get_difficulty_settings(score, "adventure")
    print(f"Score {score}: velocity_x={settings['velocity_x']}, gravity={settings['gravity']}")
