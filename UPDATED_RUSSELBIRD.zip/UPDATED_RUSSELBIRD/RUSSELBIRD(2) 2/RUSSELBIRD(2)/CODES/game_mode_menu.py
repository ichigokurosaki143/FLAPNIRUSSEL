# game_mode_menu.py
import pygame
import math
from constants import *

# === MAKE ANIMATION VARIABLES GLOBAL TO THE MODULE ===
bg_x1 = 0
bg_x2 = Game_Width
bird_frame = 0
bird_animation_timer = 0
bird_bounce_offset = 0

def game_mode_menu(window, assets, clock):
    global bg_x1, bg_x2, bird_frame, bird_animation_timer, bird_bounce_offset
    
    font = pygame.font.Font("FONT/flappy-font.ttf", 36)
    title_font = pygame.font.Font("FONT/flappy-font.ttf", 42)
    small_font = pygame.font.Font("FONT/flappy-font.ttf", 28)

    def draw_text(text, font, color, shadow, surface, x, y):
        shadow_obj = font.render(text, True, shadow)
        shadow_rect = shadow_obj.get_rect(center=(x + 2, y + 2))
        surface.blit(shadow_obj, shadow_rect)
        
        text_obj = font.render(text, True, color)
        text_rect = text_obj.get_rect(center=(x, y))
        surface.blit(text_obj, text_rect)

    # === CONSTANTS ONLY ===
    bg_speed = 1
    bird_animation_speed = 15
    bird_bounce_speed = 0.01  
    bird_bounce_range = 5

    while True:
        click = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "back"          

        # === UPDATE ANIMATION (USING GLOBAL VARIABLES) ===
        bg_x1 -= bg_speed
        bg_x2 -= bg_speed
        
        if bg_x1 <= -Game_Width:
            bg_x1 = bg_x2 + Game_Width
        if bg_x2 <= -Game_Width:
            bg_x2 = bg_x1 + Game_Width

        bird_animation_timer += 1
        if bird_animation_timer >= bird_animation_speed:
            bird_animation_timer = 0
            bird_frame = (bird_frame + 1) % 2
        
        bird_bounce_offset = math.sin(pygame.time.get_ticks() * bird_bounce_speed) * bird_bounce_range

        # --- DRAW EVERYTHING ---
        window.blit(assets["bg"], (bg_x1, 0))
        window.blit(assets["bg"], (bg_x2, 0))

        current_bird_img = assets["bird1"] if bird_frame == 0 else assets["bird2"]
        bird_rect = current_bird_img.get_rect(center=(bird_x, bird_y + bird_bounce_offset))
        window.blit(current_bird_img, bird_rect)

        draw_text("Russel In", title_font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 80)
        draw_text("The Wonderland", title_font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 140)

        draw_text("SELECT GAME MODE", font, (255, 200, 0), (0, 0, 0), window, Game_Width//2, 210)

        mx, my = pygame.mouse.get_pos()

        # CLASSIC BUTTON
        classic_rect = pygame.Rect(Game_Width // 2 - 120, Game_Height // 2 - 20, 240, 60)
        if classic_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 180, 100), classic_rect, border_radius=10)
            pygame.draw.rect(window, (50, 130, 50), classic_rect, 3, border_radius=10)
            
            if click:
                return "classic_menu"
            
        else:
            pygame.draw.rect(window, (80, 160, 80), classic_rect, border_radius=10)
            pygame.draw.rect(window, (50, 130, 50), classic_rect, 3, border_radius=10)
        
        draw_text("CLASSIC MODE", small_font, (255, 255, 255), (0, 0, 0), window, classic_rect.centerx, classic_rect.centery)

        # ADVENTURE BUTTON
        adventure_rect = pygame.Rect(Game_Width // 2 - 120, Game_Height // 2 + 80, 240, 60)
        if adventure_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 150, 200), adventure_rect, border_radius=10)
            pygame.draw.rect(window, (50, 100, 150), adventure_rect, 3, border_radius=10)
            if click:
                return "adventure_menu"
        else:
            pygame.draw.rect(window, (80, 130, 180), adventure_rect, border_radius=10)
            pygame.draw.rect(window, (50, 100, 150), adventure_rect, 3, border_radius=10)
        
        draw_text("ADVENTURE MODE", small_font, (255, 255, 255), (0, 0, 0), window, adventure_rect.centerx, adventure_rect.centery)


        # BACK BUTTON
        back_rect = pygame.Rect(Game_Width // 2 - 120, Game_Height // 2 + 180, 240, 60)
        if back_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (200, 100, 100), back_rect, border_radius=10)
            pygame.draw.rect(window, (150, 50, 50), back_rect, 3, border_radius=10)
            if click:
                return "back"
        else:
            pygame.draw.rect(window, (180, 80, 80), back_rect, border_radius=10)
            pygame.draw.rect(window, (150, 50, 50), back_rect, 3, border_radius=10)

        draw_text("BACK", small_font, (255, 255, 255), (0, 0, 0), window, back_rect.centerx, back_rect.centery)


        pygame.display.update()
        clock.tick(60)
