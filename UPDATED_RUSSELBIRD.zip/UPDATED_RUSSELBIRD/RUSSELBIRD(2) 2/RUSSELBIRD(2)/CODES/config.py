# config.py

class GameConfig:

    # SCREEN SETTINGS
    SCREEN_WIDTH = 360
    SCREEN_HEIGHT = 640
    
    # BIRD SETTINGS
    BIRD_START_X = SCREEN_WIDTH / 8
    BIRD_START_Y = SCREEN_HEIGHT / 2
    BIRD_WIDTH = 34
    BIRD_HEIGHT = 24
    
    # PIPE SETTINGS
    PIPE_OPENING_SPACE = SCREEN_HEIGHT / 5.2
    PIPE_START_X = SCREEN_WIDTH
    PIPE_START_Y = 0
    PIPE_WIDTH = 64
    PIPE_HEIGHT = 512
    
    # OSCILLATION SETTINGS
    PIPE_OSCILLATION_AMPLITUDE = 30
    PIPE_OSCILLATION_FREQUENCY = 0.002

    
    # DIFFICULTY SETTINGS
    def get_difficulty_settings(score, game_mode="adventure"):
        # Classic mode: no difficulty increase
        if game_mode == "classic":
            if score < 20:
                return {"velocity_x": -2, "gravity": 0.4, "jump_strength": -6, 
                    "osc_freq": 0.002, "osc_amp": 30}
            elif score < 30:
                return {"velocity_x": -2.8, "gravity": 0.42, "jump_strength": -6.3, 
                    "osc_freq": 0.0023, "osc_amp": 32}
            elif score < 40:
                return {"velocity_x": -3.3, "gravity": 0.45, "jump_strength": -6.6, 
                        "osc_freq": 0.0026, "osc_amp": 34}
            elif score < 50:
                return {"velocity_x": -3.8, "gravity": 0.48, "jump_strength": -6.9, 
                        "osc_freq": 0.0029, "osc_amp": 36}
            else:
                return {"velocity_x": -4.3, "gravity": 0.5, "jump_strength": -7.2, 
                        "osc_freq": 0.0032, "osc_amp": 38}
            
        # Adventure mode: progressive difficulty
        
        if score < 5:
            return {"velocity_x": -2, "gravity": 0.4, "jump_strength": -6, 
                    "osc_freq": 0.002, "osc_amp": 30}
        elif score < 10:
            return {"velocity_x": -2.8, "gravity": 0.42, "jump_strength": -6.3, 
                    "osc_freq": 0.0023, "osc_amp": 32}
        elif score < 15:
            return {"velocity_x": -3.3, "gravity": 0.45, "jump_strength": -6.6, 
                    "osc_freq": 0.0026, "osc_amp": 34}
        elif score < 20:
            return {"velocity_x": -3.8, "gravity": 0.48, "jump_strength": -6.9, 
                    "osc_freq": 0.0029, "osc_amp": 36}
        else:
            return {"velocity_x": -4.3, "gravity": 0.5, "jump_strength": -7.2, 
                    "osc_freq": 0.0032, "osc_amp": 38}