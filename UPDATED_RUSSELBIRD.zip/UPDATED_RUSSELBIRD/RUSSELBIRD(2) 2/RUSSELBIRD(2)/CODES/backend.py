"""Flask backend endpoints that delegate to the application's `database` module.
This module intentionally delegates storage and queries to `CODES/database.py` so
the same logic is shared between the game and the HTTP API.
"""
from flask import Flask, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import os

# Robust import for database module (works when running as package or from CODES dir)
try:
    from CODES import database
except Exception:
    import database

app = Flask(__name__)


def get_leaderboard(limit=3, game_mode="classic"):
    try:
        return database.get_leaderboard(limit=int(limit), game_mode=game_mode)
    except Exception as e:
        print(f"Error in get_leaderboard: {e}")
        return []


@app.route("/leaderboard", methods=["GET"])
def leaderboard_endpoint():
    try:
        limit = int(request.args.get("limit", 10))
    except Exception:
        limit = 10
    classic = database.get_leaderboard(limit, "classic")
    adventure = database.get_leaderboard(limit, "adventure")
    def row_to_obj(r):
        return {"username": r[0], "score": r[1], "played_at": r[2]}
    return jsonify({"classic": [row_to_obj(r) for r in classic], "adventure": [row_to_obj(r) for r in adventure]})


def _admin_enabled():
    # Admin endpoints are enabled only when FLAPPY_DB_UNLOCKED=1 in environment
    return os.environ.get("FLAPPY_DB_UNLOCKED") == "1"


@app.route("/admin/dump", methods=["GET"])
def admin_dump():
    if not _admin_enabled():
        return jsonify({"error": "admin endpoints disabled"}), 403
    conn = database.get_connection()
    cur = conn.cursor()
    # return limited dump of all tables
    cur.execute("SELECT id, username, created_at FROM users ORDER BY id DESC LIMIT 200")
    users = cur.fetchall()
    cur.execute("SELECT id, username, score, played_at, game_mode FROM leaderboard ORDER BY id DESC LIMIT 500")
    leaderboard = cur.fetchall()
    cur.execute("SELECT id, achievement_name, earned_at, game_mode FROM achievements ORDER BY id DESC LIMIT 500")
    achievements = cur.fetchall()
    conn.close()
    return jsonify({"users": users, "leaderboard": leaderboard, "achievements": achievements})


@app.route("/admin/reset", methods=["POST"])
def admin_reset():
    if not _admin_enabled():
        return jsonify({"error": "admin endpoints disabled"}), 403
    conn = database.get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM achievements")
    cur.execute("DELETE FROM leaderboard")
    cur.execute("DELETE FROM users")
    conn.commit()
    conn.close()
    return jsonify({"message": "database reset completed"})


@app.route("/signup", methods=["POST"])
def signup():
    data = request.json or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Missing username or password"}), 400

    pwd_hash = generate_password_hash(password)
    ok = database.add_user(username, pwd_hash)
    if ok:
        return jsonify({"message": "Account created!"})
    return jsonify({"error": "Username already exists!"}), 400


@app.route("/login", methods=["POST"])
def login():
    data = request.json or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Missing username or password"}), 400

    auth = database.authenticate_user(username)
    if not auth:
        return jsonify({"error": "Invalid username or password"}), 400

    user_id, pw_hash = auth
    if check_password_hash(pw_hash, password):
        return jsonify({"message": "Login successful!", "user_id": user_id})
    return jsonify({"error": "Invalid username or password"}), 400


@app.route("/add_achievement", methods=["POST"])
def add_achievement_endpoint():
    data = request.json or {}
    username = data.get("username")
    achievement_name = data.get("achievement")
    game_mode = data.get("game_mode", "classic")
    if not username or not achievement_name:
        return jsonify({"error": "Missing fields"}), 400
    ok = database.add_achievement(username, achievement_name, game_mode)
    if ok:
        return jsonify({"message": "Achievement added!"})
    return jsonify({"error": "Could not add achievement"}), 400


@app.route("/achievements/<username>", methods=["GET"])
def achievements(username):
    game_mode = request.args.get('game_mode')
    rows = database.get_achievements(username, game_mode=game_mode)
    return jsonify([{"achievement": r[0], "date": r[1], "game_mode": r[2]} for r in rows])

