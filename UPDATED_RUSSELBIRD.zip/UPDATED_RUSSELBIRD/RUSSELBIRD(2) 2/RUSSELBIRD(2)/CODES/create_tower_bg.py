import pygame
import os

# Initialize Pygame
pygame.init()

# Create a surface that matches game dimensions
width, height = 360, 640
surface = pygame.Surface((width, height))

# Sky blue gradient background
sky_blue = (135, 206, 250)
for y in range(height):
    color_blend = int(135 + (106 - 135) * (y / height))
    pygame.draw.line(surface, (color_blend, 206, 250), (0, y), (width, y))

# Draw green ground at bottom
ground_y = int(height * 0.75)
pygame.draw.rect(surface, (34, 139, 34), (0, ground_y, width, height - ground_y))

# Draw some bushes/scenery
for i in range(3):
    x = 20 + i * 140
    pygame.draw.polygon(surface, (34, 180, 34), [(x, ground_y), (x + 40, ground_y - 30), (x + 80, ground_y)])
    pygame.draw.polygon(surface, (46, 200, 46), [(x + 30, ground_y - 15), (x + 70, ground_y - 45), (x + 110, ground_y - 15)])

# Draw the main tower building (simplified pixel art style)
# Tower base
tower_x = 110
tower_y = ground_y - 150
tower_width = 140
tower_height = 150

# Main tower body
pygame.draw.rect(surface, (200, 200, 200), (tower_x, tower_y, tower_width, tower_height))
pygame.draw.rect(surface, (150, 150, 150), (tower_x, tower_y, tower_width, tower_height), 3)

# Tower roof
pygame.draw.polygon(surface, (255, 255, 0), [(tower_x - 5, tower_y), (tower_x + tower_width // 2, tower_y - 30), (tower_x + tower_width + 5, tower_y)])
pygame.draw.polygon(surface, (200, 200, 0), [(tower_x - 5, tower_y), (tower_x + tower_width // 2, tower_y - 30), (tower_x + tower_width + 5, tower_y)], 2)

# Roof sign (STI style)
sign_x = tower_x + tower_width // 2 - 25
sign_y = tower_y - 35
pygame.draw.rect(surface, (255, 255, 0), (sign_x, sign_y, 50, 15))
pygame.draw.rect(surface, (0, 0, 0), (sign_x, sign_y, 50, 15), 2)

# Add STI text on the roof sign
font_sti = pygame.font.Font(None, 12)
sti_text = font_sti.render("STI", True, (0, 0, 0))
sti_rect = sti_text.get_rect(center=(sign_x + 25, sign_y + 8))
surface.blit(sti_text, sti_rect)

# Tower windows - left section
window_color = (0, 150, 200)
window_outline = (0, 0, 0)
for row in range(4):
    for col in range(2):
        wx = tower_x + 15 + col * 35
        wy = tower_y + 20 + row * 28
        pygame.draw.rect(surface, window_color, (wx, wy, 28, 24))
        pygame.draw.rect(surface, window_outline, (wx, wy, 28, 24), 1)
        # Window panes
        pygame.draw.line(surface, window_outline, (wx + 14, wy), (wx + 14, wy + 24), 1)
        pygame.draw.line(surface, window_outline, (wx, wy + 12), (wx + 28, wy + 12), 1)

# Tower windows - right section
for row in range(4):
    for col in range(2):
        wx = tower_x + 80 + col * 30
        wy = tower_y + 20 + row * 28
        pygame.draw.rect(surface, (255, 255, 150), (wx, wy, 24, 24))
        pygame.draw.rect(surface, window_outline, (wx, wy, 24, 24), 1)
        # Window panes
        pygame.draw.line(surface, window_outline, (wx + 12, wy), (wx + 12, wy + 24), 1)
        pygame.draw.line(surface, window_outline, (wx, wy + 12), (wx + 24, wy + 12), 1)

# Tower entrance at bottom
entrance_x = tower_x + tower_width // 2 - 20
entrance_y = tower_y + tower_height - 40
pygame.draw.rect(surface, (80, 80, 80), (entrance_x, entrance_y, 40, 40))
pygame.draw.rect(surface, (0, 0, 0), (entrance_x, entrance_y, 40, 40), 2)

# Draw entrance doors
pygame.draw.line(surface, (0, 0, 0), (entrance_x + 20, entrance_y), (entrance_x + 20, entrance_y + 40), 2)

# Draw some tall pillars on sides
for i in range(2):
    pillar_x = 20 + i * 320
    pygame.draw.rect(surface, (255, 220, 0), (pillar_x, ground_y - 120, 25, 120))
    pygame.draw.rect(surface, (200, 170, 0), (pillar_x, ground_y - 120, 25, 120), 2)
    # Pillar top
    pygame.draw.rect(surface, (255, 255, 100), (pillar_x - 5, ground_y - 125, 35, 5))

# Draw clouds
def draw_cloud(surface, x, y, size=40):
    pygame.draw.circle(surface, (255, 255, 255), (x, y), size)
    pygame.draw.circle(surface, (255, 255, 255), (x + size, y), int(size * 0.8))
    pygame.draw.circle(surface, (255, 255, 255), (x - size, y), int(size * 0.7))

draw_cloud(surface, 50, 80, 35)
draw_cloud(surface, 280, 120, 40)

# Save the image
output_path = os.path.join(os.path.dirname(__file__), "..", "IMAGES", "tower_bg.png")
pygame.image.save(surface, output_path)
print(f"Tower background saved to {output_path}")

pygame.quit()
