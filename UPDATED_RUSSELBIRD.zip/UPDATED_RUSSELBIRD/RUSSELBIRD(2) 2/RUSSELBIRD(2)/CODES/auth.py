import pygame
from constants import Game_Width, Game_Height
from werkzeug.security import generate_password_hash, check_password_hash
# Robust import for database
try:
    from CODES import database
except Exception:
    import database

import session


def auth_menu(window, assets, clock):
    """Simple auth UI: toggle between Login and Sign Up."""
    font_title = pygame.font.Font("FONT/flappy-font.ttf", 40)
    font_text = pygame.font.Font("FONT/flappy-font.ttf", 24)
    font_medium = pygame.font.Font("FONT/flappy-font.ttf", 20)
    font_small = pygame.font.Font("FONT/flappy-font.ttf", 13)
    font_small2 = pygame.font.Font("FONT/flappy-font.ttf", 12)

    mode = "login"  # or "signup"
    username = ""
    password = ""
    input_field = "username"  # or "password"
    message = ""
    message_timer = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
                if event.key == pygame.K_TAB:
                    input_field = "password" if input_field == "username" else "username"
                if event.key == pygame.K_RETURN:
                    if len(username) == 0 or len(password) == 0:
                        message = "Please enter username and password"
                        message_timer = 120
                    else:
                        if mode == "signup":
                            # create user
                            ph = generate_password_hash(password)
                            ok = database.add_user(username, ph)
                            if ok:
                                session.set_user(username)
                                return
                            else:
                                message = "Signup failed (maybe user exists)"
                                message_timer = 120
                        else:
                            # login
                            auth = database.authenticate_user(username)
                            if auth:
                                user_id, pw_hash = auth
                                if check_password_hash(pw_hash, password):
                                    session.set_user(username)
                                    return
                                else:
                                    message = "Incorrect password"
                                    message_timer = 120
                            else:
                                message = "User not found"
                                message_timer = 120
                elif event.key == pygame.K_BACKSPACE:
                    if input_field == "username":
                        username = username[:-1]
                    else:
                        password = password[:-1]
                else:
                    ch = event.unicode
                    if ch and len(ch) == 1 and (ch.isalnum() or ch in " _-@"):
                        if input_field == "username" and len(username) < 20:
                            username += ch
                        if input_field == "password" and len(password) < 32:
                            password += ch
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = pygame.mouse.get_pos()
                # Toggle mode buttons positions
                if Game_Width//2 - 120 <= mx <= Game_Width//2 - 20 and Game_Height//2 + 110 <= my <= Game_Height//2 + 150:
                    mode = "login"
                if Game_Width//2 + 20 <= mx <= Game_Width//2 + 120 and Game_Height//2 + 110 <= my <= Game_Height//2 + 150:
                    mode = "signup"

        if message_timer > 0:
            message_timer -= 1
        else:
            message = ""

        # draw
        window.fill((20, 30, 50))
        title = font_title.render("Account", True, (255, 215, 0))
        title_rect = title.get_rect(center=(Game_Width//2, 80))
        window.blit(title, title_rect)

        # mode buttons
        login_rect = pygame.Rect(Game_Width//2 - 120, Game_Height//2 + 110, 100, 40)
        signup_rect = pygame.Rect(Game_Width//2 + 20, Game_Height//2 + 110, 100, 40)

        pygame.draw.rect(window, (100, 100, 180) if mode == "login" else (60, 60, 120), login_rect, border_radius=6)
        pygame.draw.rect(window, (100, 100, 180) if mode == "signup" else (60, 60, 120), signup_rect, border_radius=6)

        ltext = font_medium.render("Login", True, (255,255,255))
        stext = font_medium.render("Sign Up", True, (255,255,255))
        window.blit(ltext, (login_rect.x + 22, login_rect.y + 8))
        window.blit(stext, (signup_rect.x + 18, signup_rect.y + 8))

        # input boxes
        input_w = 320
        input_h = 40
        x = (Game_Width - input_w) // 2
        y = Game_Height//2 - 30

        pygame.draw.rect(window, (255,255,255), (x, y, input_w, input_h), border_radius=6)
        pygame.draw.rect(window, (200,200,200), (x, y+60, input_w, input_h), border_radius=6)

        uname_disp = username + ("|" if int((pygame.time.get_ticks()//500))%2 else "")
        pwd_disp = ("*" * len(password)) + ("|" if int((pygame.time.get_ticks()//500))%2 else "")

        utext = font_text.render(uname_disp, True, (0,0,0))
        ptext = font_text.render(pwd_disp, True, (0,0,0))

        window.blit(utext, (x+10, y+8))
        window.blit(ptext, (x+10, y+68))

        instr = font_small2.render("TAB to switch field, ENTER to submit, ESC to cancel", True, (255, 255, 255))
        window.blit(instr, ((Game_Width - instr.get_width())//2, y + 200))

        if message:
            mtext = font_small.render(message, True, (255,100,100))
            window.blit(mtext, ((Game_Width - mtext.get_width())//2, y + 150))


        if not session.get_user():
            msg_font = pygame.font.Font("FONT/flappy-font.ttf", 16)
            warning = msg_font.render("You must be logged in to play the game.", True, (255, 100, 100))
            window.blit(warning, (Game_Width // 2 - warning.get_width() //2, Game_Height //2 + 200))


        pygame.display.update()
        clock.tick(60)
