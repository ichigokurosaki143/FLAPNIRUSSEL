# game_functions.py

import pygame, math, random
from constants import *
from pipes import Pipe
from config import *

# === NEW HELPER FUNCTIONS ===
def draw_background (window, assets, bg_x1, bg_x2):
    # Draw scrolling background
    window.blit (assets["bg"], (bg_x1, 0))
    window.blit (assets["bg"], (bg_x2, 0))

def draw_pipes (window, pipes):
    # Draw all pipes
    for pipe in pipes:
        window.blit (pipe.img, pipe)

def draw_bird (window, bird):
    # Draw the bird with rotation
    rotated_bird = bird.get_rotated_image ()
    bird_rect = rotated_bird.get_rect (center = bird.center)
    window.blit (rotated_bird, bird_rect)

def draw_ground (window, assets, ground_x1, ground_x2):
    # Draw scrolling ground
    ground_y = Game_Height - 62.5
    window.blit (assets["ground"], (ground_x1, ground_y))
    window.blit (assets["ground"], (ground_x2, ground_y))

def draw_score (window, score, game_over):
    # Draw current score during gameplay
    if game_over:
        return
        
    font_big = pygame.font.Font ("FONT/flappy-font.ttf", 48)
    text = font_big.render (f"{int(score)}", True, (255, 255, 255))
    shadow = font_big.render (f"{int(score)}", True, (0, 0, 0))
    text_rect = text.get_rect (center = (Game_Width / 2, 80))
    shadow_rect = shadow.get_rect (center = (Game_Width / 2 + 2, 82))
    window.blit (shadow, shadow_rect)
    window.blit (text, text_rect)

def draw_game_over_screen (window, score, high_score):
    # Draw game over screen with scoreboard
    font_big = pygame.font.Font ("FONT/flappy-font.ttf", 48)
    font_small = pygame.font.Font ("FONT/flappy-font.ttf", 28)
    
    # Scoreboard dimensions
    board_w, board_h = 265, 225
    board_x, board_y = (Game_Width - board_w) / 2, (Game_Height - board_h) / 2
    
    # Draw scoreboard
    pygame.draw.rect (window, (245, 222, 179), (board_x, board_y, board_w, board_h), border_radius = 15)
    pygame.draw.rect (window, (222, 184, 135), (board_x, board_y, board_w, board_h), 4, border_radius = 15)

    # Game over text
    title = font_big.render ("GAME OVER", True, (255, 255, 255))
    title_shadow = font_big.render ("GAME OVER", True, (0, 0, 0))
    title_rect = title.get_rect (center = (board_x + board_w / 2, board_y + 50))
    title_shadow_rect = title_shadow.get_rect (center = (board_x + board_w / 2 + 2, board_y + 52))
    window.blit (title_shadow, title_shadow_rect)
    window.blit (title, title_rect)

    # Scores
    score_text = font_small.render (f"Score: {int(score)}", True, (0, 0, 0))
    best_text = font_small.render (f"Best: {int(high_score)}", True, (0, 0, 0))
    score_rect = score_text.get_rect (center=(board_x + board_w / 2, board_y + 105))
    best_rect = best_text.get_rect (center = (board_x + board_w / 2, board_y + 135))
    window.blit (score_text, score_rect)
    window.blit (best_text, best_rect)

    # Restart instruction
    restart_font = pygame.font.Font ("FONT/flappy-font.ttf", 20) 
    restart_text = restart_font.render ("Press SPACE to Restart", True, (80, 60, 40))
    restart_rect = restart_text.get_rect (center = (board_x + board_w / 2, board_y + board_h - 40))
    window.blit (restart_text, restart_rect)

    # Quit to menu
    quit_font = pygame.font.Font ("FONT/flappy-font.ttf", 20)
    quit_text = quit_font.render ("Press Q to Quit to Menu", True, (80, 60, 40))
    quit_rect = quit_text.get_rect (center=(board_x + board_w / 2, board_y + board_h - 15))
    window.blit (quit_text, quit_rect)

def update_difficulty(score, game_mode="adventure"):
    # Get difficulty settings based on current score and game mode
    return GameConfig.get_difficulty_settings(score, game_mode)

# === MAIN DRAW FUNCTION ===
def draw (window, bird, pipes, assets, score, high_score, game_over, bg_x1, bg_x2, ground_x1, ground_x2):
    # Draw all game elements
    draw_background (window, assets, bg_x1, bg_x2)
    draw_pipes (window, pipes)
    draw_bird (window, bird)
    draw_ground (window, assets, ground_x1, ground_x2)
    draw_score (window, score, game_over)
    
    if game_over:
        draw_game_over_screen(window, score, high_score)

# === MAIN MOVE FUNCTION ===
def move (bird, pipes, sounds, game_state, game_mode="adventure"):
    velocity_y, score, high_score, game_over, velocity_x, gravity, jump_strength, Pipe_Osc_Freq, Pipe_Osc_Amp, ground_speed = game_state

    # UPDATE DIFFICULTY BASED ON SCORE AND GAME MODE
    difficulty = update_difficulty (score, game_mode)
    velocity_x = difficulty ["velocity_x"]
    gravity = difficulty ["gravity"] 
    jump_strength = difficulty ["jump_strength"]
    Pipe_Osc_Freq = difficulty ["osc_freq"]
    Pipe_Osc_Amp = difficulty ["osc_amp"]

    # === GROUND MOVEMENT ===
    ground_speed = velocity_x
    velocity_y += gravity
    
    # === BIRD MOVEMENT ===
    bird.y += velocity_y
    bird.y = max (bird.y, 0)

    # === GROUND COLLISION AND SKY COLLISION ===
    ground_y = Game_Height - 62.5 - bird_h  # ground height = 62.5
    if bird.y >= ground_y or bird.y <= 0:
        bird.y = min (max(bird.y, 0), ground_y)
        sounds["hit"].play ()
        sounds["die"].play ()
        if score > high_score:
            high_score = score
        game_over = True
        return velocity_y, score, high_score, game_over, velocity_x, gravity, jump_strength, Pipe_Osc_Freq, Pipe_Osc_Amp, ground_speed

    # === PIPE MOVEMENT AND COLLISION ===
    pipe_index = 0
    while pipe_index < len(pipes):
        top_pipe = pipes[pipe_index]
        bottom_pipe = pipes[pipe_index + 1] if pipe_index + 1 < len(pipes) else None
        top_pipe.x += velocity_x
        if bottom_pipe:
            bottom_pipe.x = top_pipe.x
        
        # --- PIPE OSCILLATION ---
        # Only oscillate pipes in Adventure mode, not in Classic mode
        if game_mode == "adventure" and score >= 10:
            elapsed = (pygame.time.get_ticks() - top_pipe.spawn_time)
            offset = math.sin(elapsed * Pipe_Osc_Freq + top_pipe.phase_offset) * Pipe_Osc_Amp
            top_pipe.y = top_pipe.base_y + offset
            if bottom_pipe:
                bottom_pipe.y = top_pipe.y + top_pipe.h + Opening_Space
        
        # --- PIPE COLLISION ---
        if not top_pipe.passed and bird.x > top_pipe.x + pipes_w:
            sounds["point"].play()
            score += 1
        
            top_pipe.passed = True
            if bottom_pipe:
                bottom_pipe.passed = True
        
        # --- CHECK FOR COLLISION ---
        if bird.colliderect(top_pipe) or (bottom_pipe and bird.colliderect(bottom_pipe)):
            sounds["hit"].play()
            sounds["die"].play()
            if score > high_score:
                high_score = score
            game_over = True
            return velocity_y, score, high_score, game_over, velocity_x, gravity, jump_strength, Pipe_Osc_Freq, Pipe_Osc_Amp, ground_speed

        pipe_index += 2

    # Remove off-screen pipes
    while len(pipes) >= 2 and pipes[0].x < -pipes_w:
        pipes.pop(0)
        pipes.pop(0)

    return velocity_y, score, high_score, game_over, velocity_x, gravity, jump_strength, Pipe_Osc_Freq, Pipe_Osc_Amp, ground_speed

# === PIPE CREATION FUNCTION ===
def create_pipe_pair(pipes, top_img, bottom_img):
    # Create a pair of pipes (top and bottom) with random vertical position
    random_pipe_y = pipes_y - pipes_h / 4 - random.random() * (pipes_h / 2)
    phase_offset = random.uniform(0, math.pi * 2)

    top_pipe = Pipe(top_img, phase_offset)
    top_pipe.y = random_pipe_y
    top_pipe.base_y = top_pipe.y
    pipes.append(top_pipe)

    bottom_pipe = Pipe(bottom_img, phase_offset)
    bottom_pipe.y = top_pipe.y + top_pipe.h + Opening_Space
    bottom_pipe.base_y = bottom_pipe.y
    pipes.append(bottom_pipe)