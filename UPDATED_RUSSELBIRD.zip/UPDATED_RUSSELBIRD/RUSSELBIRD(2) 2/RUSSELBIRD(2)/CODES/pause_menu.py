# pause_menu.py
import pygame
from constants import Game_Width, Game_Height
from transition import fade_effect

def pause_menu(window, clock, game_surface=None):
    font = pygame.font.Font("FONT/flappy-font.ttf", 50)
    small_font = pygame.font.Font("FONT/flappy-font.ttf", 30)

    def draw_text(text, font, color, shadow_color, surface, x, y):
        shadow = font.render(text, True, shadow_color)
        shadow_rect = shadow.get_rect(center=(x + 2, y + 2))
        surface.blit(shadow, shadow_rect)
        
        text_obj = font.render(text, True, color)
        text_rect = text_obj.get_rect(center=(x, y))
        surface.blit(text_obj, text_rect)

    # Create a semi-transparent overlay
    overlay = pygame.Surface((Game_Width, Game_Height), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 128))
    

    while True:
        click = False

        # Event Handling 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_p, pygame.K_ESCAPE):
                    return "resume"
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True

        # --- Draw current game in background ---
        if game_surface:
            window.blit(game_surface, (0, 0))
        
        # --- Draw semi-transparent overlay ---
        window.blit(overlay, (0, 0))

        # --- Title ---
        draw_text("PAUSED", font, (255, 255, 255), (0, 0, 0), window, Game_Width//2, 120)

        mx, my = pygame.mouse.get_pos()

        # --- Buttons ---
        resume_rect = pygame.Rect(Game_Width//2 - 100, Game_Height//2 - 20, 200, 50)
        exit_rect   = pygame.Rect(Game_Width//2 - 100, Game_Height//2 + 70, 200, 50)

        # Resume button
        if resume_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (100, 200, 100), resume_rect, border_radius=10)
            pygame.draw.rect(window, (50, 150, 50), resume_rect, 3, border_radius=10)
            if click:
                return "resume"
        else:
            pygame.draw.rect(window, (80, 180, 80), resume_rect, border_radius=10)
            pygame.draw.rect(window, (50, 150, 50), resume_rect, 3, border_radius=10)
        
        draw_text("RESUME", small_font, (255, 255, 255), (0, 0, 0), window, resume_rect.centerx, resume_rect.centery)

        # Exit button
        if exit_rect.collidepoint((mx, my)):
            pygame.draw.rect(window, (200, 100, 100), exit_rect, border_radius=10)
            pygame.draw.rect(window, (150, 50, 50), exit_rect, 3, border_radius=10)
            if click:
                fade_effect (window)
                return "exit"
        else:
            pygame.draw.rect(window, (180, 80, 80), exit_rect, border_radius=10)
            pygame.draw.rect(window, (150, 50, 50), exit_rect, 3, border_radius=10)
        
        draw_text("EXIT TO MENU", small_font, (255, 255, 255), (0, 0, 0), window, exit_rect.centerx, exit_rect.centery)

        pygame.display.update()
        clock.tick (60)