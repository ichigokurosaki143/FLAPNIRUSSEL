# settings_.py
from config import GameConfig

# === GAME DIMENSIONS AND SETTINGS ===

# Screen dimensions
Game_Width = GameConfig.SCREEN_WIDTH
Game_Height = GameConfig.SCREEN_HEIGHT

# Pipe settings
Opening_Space = GameConfig.PIPE_OPENING_SPACE
Pipe_Osc_Amp = GameConfig.PIPE_OSCILLATION_AMPLITUDE
Pipe_Osc_Freq = GameConfig.PIPE_OSCILLATION_FREQUENCY

# Bird settings
bird_x = GameConfig.BIRD_START_X
bird_y = GameConfig.BIRD_START_Y
bird_w = GameConfig.BIRD_WIDTH
bird_h = GameConfig.BIRD_HEIGHT

# Pipe settings
pipes_x = GameConfig.PIPE_START_X
pipes_y = GameConfig.PIPE_START_Y
pipes_w = GameConfig.PIPE_WIDTH
pipes_h = GameConfig.PIPE_HEIGHT

