import sqlite3

conn = sqlite3.connect('flappybird.db')
cursor = conn.cursor()

print("Tables in database:")
cursor.execute("SELECT * FROM scores ORDER BY score DESC ")
tables = cursor.fetchall()
for table in tables:
    print(f'  - {table[0]}')

print('\nLeaderboard table structure:')
cursor.execute('PRAGMA table_info(leaderboard)')
columns = cursor.fetchall()
for col in columns:
    print(f'  {col[1]}: {col[2]}')

print('\nSample data from leaderboard:')
cursor.execute('SELECT username, score, game_mode, played_at FROM leaderboard LIMIT 5')
data = cursor.fetchall()
for row in data:
    print(f'  {row}')

conn.close()
print("\n✓ Database structure verified!")
