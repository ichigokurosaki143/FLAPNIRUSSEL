import os, sys
here = os.path.dirname(os.path.abspath(__file__))
repo_root = os.path.dirname(here)
codes_path = os.path.join(repo_root, 'CODES')
sys.path.insert(0, codes_path)
# Try package import first, fallback to local module
try:
    from CODES import database
except Exception:
    import database

conn = database.get_connection()
cur = conn.cursor()

print('--- users ---')
cur.execute("SELECT id, username, password_hash, created_at FROM users LIMIT 20")
for r in cur.fetchall():
    print(r)

print('\n--- leaderboard (last 20) ---')
cur.execute("SELECT id, user_id, username, score, played_at, game_mode FROM leaderboard ORDER BY id DESC LIMIT 20")
for r in cur.fetchall():
    print(r)

print('\n--- achievements ---')
cur.execute("SELECT id, user_id, achievement_name, earned_at FROM achievements ORDER BY id DESC LIMIT 20")
for r in cur.fetchall():
    print(r)

conn.close()
