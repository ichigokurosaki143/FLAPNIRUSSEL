import unittest
import time
import os
import sys
import tempfile

# Create a temporary DB file for isolated testing and set env var before importing CODES.database
tmp_db = tempfile.NamedTemporaryFile(prefix="flappy_test_", suffix=".db", delete=False)
tmp_db_path = tmp_db.name
tmp_db.close()
os.environ['FLAPPY_DB'] = tmp_db_path

# ensure CODES package is importable when running tests from any working directory
here = os.path.dirname(os.path.abspath(__file__))
repo_root = os.path.dirname(here)
codes_path = os.path.join(repo_root, 'CODES')
codes_path = os.path.normpath(codes_path)
if codes_path not in sys.path:
    sys.path.insert(0, codes_path)

import database
from werkzeug.security import generate_password_hash, check_password_hash

TEST_USER = f"test_user_{int(time.time())}"
TEST_USER2 = f"test_user2_{int(time.time())}"

class TestDatabaseModule(unittest.TestCase):
    def setUp(self):
        # Ensure a clean database state before each test
        try:
            database.init_db()
            conn = database.get_connection()
            cur = conn.cursor()
            cur.execute("DELETE FROM achievements")
            cur.execute("DELETE FROM leaderboard")
            cur.execute("DELETE FROM users")
            conn.commit()
            conn.close()
        except Exception as e:
            # If cleanup fails, raise so the test framework reports the issue
            raise
    def test_init_db(self):
        # Ensure init runs without error
        try:
            database.init_db()
        except Exception as e:
            self.fail(f"init_db raised exception: {e}")

    def test_user_add_and_auth(self):
        ph = generate_password_hash("pass123")
        ok = database.add_user(TEST_USER, ph)
        self.assertTrue(ok, "add_user should return True")

        auth = database.authenticate_user(TEST_USER)
        self.assertIsNotNone(auth, "authenticate_user should return a tuple")
        user_id, pw_hash = auth
        self.assertTrue(check_password_hash(pw_hash, "pass123"))
        # quiet: no debug prints

    def test_add_scores_and_leaderboards(self):
        # add classic and adventure scores for two users
        s1 = database.add_score(TEST_USER, 50, "classic")
        s2 = database.add_score(TEST_USER, 120, "adventure")
        self.assertTrue(s1)
        self.assertTrue(s2)

        # add for second user
        ph2 = generate_password_hash("pwd2")
        database.add_user(TEST_USER2, ph2)
        database.add_score(TEST_USER2, 80, "classic")

        # fetch leaderboards
        classic = database.get_leaderboard(5, "classic")
        adventure = database.get_leaderboard(5, "adventure")

        # classic should contain at least one of our test users
        usernames = [r[0] for r in classic]
        self.assertIn(TEST_USER, usernames + [None] if usernames else [None])
        # adventure leaderboard should contain TEST_USER
        adv_names = [r[0] for r in adventure]
        self.assertIn(TEST_USER, adv_names)
        # quiet: no debug prints

    def test_achievements_and_duplicates(self):
        # Ensure the test user exists (tests should be independent)
        ph = generate_password_hash("pass123")
        database.add_user(TEST_USER, ph)

        # Ensure no achievements exist initially
        before = database.get_achievements(TEST_USER)
        # debug prints removed
        # add achievement (use unique name to avoid leftovers from previous runs)
        ach_name = f"UnitTest Achievement {int(time.time())}"
        ok = database.add_achievement(TEST_USER, ach_name)
        # debug prints removed
        self.assertTrue(ok)
        # re-add should be prevented
        ok2 = database.add_achievement(TEST_USER, ach_name)
        self.assertFalse(ok2)

        after = database.get_achievements(TEST_USER)
        names = [a[0] for a in after]
        self.assertIn(ach_name, names)

if __name__ == "__main__":
    try:
        unittest.main()
    finally:
        # clean up temp DB file
        try:
            os.remove(tmp_db_path)
        except Exception:
            pass
